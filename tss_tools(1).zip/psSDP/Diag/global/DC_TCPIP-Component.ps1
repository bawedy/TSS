﻿#************************************************
# DC_TCPIP-Component.ps1
# Version 1.0: Collects information from the registry, netsh, arp, ipconfig, etc. 
# Version 1.1: Updated IPv6 Transition Technologies section for SKU checks to clean up exceptions.
# Version 1.2: Altered the runPS function correctly a column width issue.
# Version 1.3: Corrected the code for Get-NetCompartment (only runs in WS2012+)
# Version 1.4.09.10.14: Add additional netsh commands for Teredo and ISATAP. TFS264243
# Date: 2009-2014 /WalterE 2019 - GetNetTcpConnEstablished
# Author: Boyd Benson (bbenson@microsoft.com)
# Description: Collects information about TCPIP.
# Called from: Networking Diags
#*******************************************************


Trap [Exception]
	{
	 # Handle exception and throw it to the stdout log file. Then continue with function and script.
		 $Script:ExceptionMessage = $_
		 "[info]: Exception occurred."  | WriteTo-StdOut
		 "[info]: Exception.Message $ExceptionMessage."  | WriteTo-StdOut 
		 $Error.Clear()
		 continue
	}

Import-LocalizedData -BindingVariable ScriptVariable
Write-DiagProgress -Activity $ScriptVariable.ID_CTSTCPIP -Status $ScriptVariable.ID_CTSTCPIPDescription

"[info]:TCPIP-Component:BEGIN" | WriteTo-StdOut


function RunNetSH ([string]$NetSHCommandToExecute="")
{
	Write-DiagProgress -Activity $ScriptVariable.ID_CTSTCPIP -Status "netsh $NetSHCommandToExecute"
	$NetSHCommandToExecuteLength = $NetSHCommandToExecute.Length + 6
	"-" * ($NetSHCommandToExecuteLength)	| Out-File -FilePath $outputFile -append
	"netsh $NetSHCommandToExecute"			| Out-File -FilePath $outputFile -append
	"-" * ($NetSHCommandToExecuteLength)	| Out-File -FilePath $outputFile -append
	$CommandToExecute = "cmd.exe /c netsh.exe " + $NetSHCommandToExecute + " >> $outputFile "
	RunCmD -commandToRun $CommandToExecute  -CollectFiles $false
	"`n" | Out-File -FilePath $outputFile -append
	"`n" | Out-File -FilePath $outputFile -append
	"`n" | Out-File -FilePath $outputFile -append
}


function RunPS ([string]$RunPScmd="", [switch]$ft)
{
	$RunPScmdLength = $RunPScmd.Length
	"-" * ($RunPScmdLength)		| Out-File -FilePath $OutputFile -append
	"$RunPScmd"  				| Out-File -FilePath $OutputFile -append
	"-" * ($RunPScmdLength)  	| Out-File -FilePath $OutputFile -append
	
	if ($ft)
	{
		# This format-table expression is useful to make sure that wide ft output works correctly
		Invoke-Expression $RunPScmd	|format-table -autosize -outvariable $FormatTableTempVar | Out-File -FilePath $outputFile -Width 500 -append
	}
	else
	{
		Invoke-Expression $RunPScmd	| Out-File -FilePath $OutputFile -append
	}
	"`n" | Out-File -FilePath $outputFile -append
	"`n" | Out-File -FilePath $outputFile -append
	"`n" | Out-File -FilePath $outputFile -append
}


function RunNetCmd ([string]$NetCmd="", [string]$NetCmdArg="")
{
	Write-DiagProgress -Activity $ScriptVariable.ID_CTSTCPIP -Status "$NetCmd $NetCmdArg"
	$NetCmdLen = $NetCmd.length
	$NetCmdArgLen = $NetCmdArg.Length
	$NetCmdFullLen = $NetCmdLen + $NetCmdArgLen + 1
	"-" * ($NetCmdFullLen)	| Out-File -FilePath $outputFile -append
	"$NetCmd $NetCmdArg"	| Out-File -FilePath $outputFile -append
	"-" * ($NetCmdFullLen)	| Out-File -FilePath $outputFile -append
	$CommandToExecute = "cmd.exe /c $NetCmd $NetCmdArg >> $outputFile"
	RunCmD -commandToRun $CommandToExecute  -CollectFiles $false
	"`n" | Out-File -FilePath $outputFile -append
	"`n" | Out-File -FilePath $outputFile -append
	"`n" | Out-File -FilePath $outputFile -append	
}


function Heading ([string]$header)
{
	"=" * ($borderLen)	| Out-File -FilePath $outputFile -append
	"$header"			| Out-File -FilePath $outputFile -append
	"=" * ($borderLen)	| Out-File -FilePath $outputFile -append
	"`n" | Out-File -FilePath $outputFile -append
	"`n" | Out-File -FilePath $outputFile -append
	"`n" | Out-File -FilePath $outputFile -append
}

function GetNetTcpConnEstablished ()
{
	#get all TCP established connections and match them with its process. Similar output is thrown by using: netstat -ano
	$AllConnections = @()
	$Connections = Get-NetTCPConnection -State Established | Select-Object LocalAddress,LocalPort,RemoteAddress,RemotePort,OwningProcess
	ForEach($Connection In $Connections) {
		$ProcessInfo = Get-Process -PID $Connection.OwningProcess -IncludeUserName | Select-Object Path,UserName,StartTime,Name,Id
		$Obj = New-Object -TypeName PSObject
		Add-Member -InputObject $Obj -MemberType NoteProperty -Name LocalAddress -Value $Connection.LocalAddress
		Add-Member -InputObject $Obj -MemberType NoteProperty -Name LocalPort -Value $Connection.LocalPort
		Add-Member -InputObject $Obj -MemberType NoteProperty -Name RemoteAddress -Value $Connection.RemoteAddress
		Add-Member -InputObject $Obj -MemberType NoteProperty -Name RemotePort -Value $Connection.RemotePort
		Add-Member -InputObject $Obj -MemberType NoteProperty -Name OwningProcessID -Value $Connection.OwningProcess
		Add-Member -InputObject $Obj -MemberType NoteProperty -Name ProcessName -Value $ProcessInfo.Name
		Add-Member -InputObject $Obj -MemberType NoteProperty -Name UserName -Value $ProcessInfo.UserName
		Add-Member -InputObject $Obj -MemberType NoteProperty -Name CommandLine -Value $ProcessInfo.Path
		Add-Member -InputObject $Obj -MemberType NoteProperty -Name StartTime -Value $ProcessInfo.StartTime
		$AllConnections += $Obj
	}
	$AllConnections #|format-table -autosize
}


$sectionDescription = "TCPIP"
$borderLen = 52

# detect OS version and SKU
$wmiOSVersion = gwmi -Namespace "root\cimv2" -Class Win32_OperatingSystem
[int]$bn = [int]$wmiOSVersion.BuildNumber



####################################################
# General Information
####################################################
#-----MAIN TCPIP INFO  (W2003+)

#----------TCPIP Information from Various Tools
$outputFile = join-path $pwd.path ($ComputerName + "_TCPIP_info.TXT")
"=" * ($borderLen)									| Out-File -FilePath $outputFile -append
"TCPIP Networking Information"						| Out-File -FilePath $OutputFile -append
"=" * ($borderLen)									| Out-File -FilePath $outputFile -append
"Overview"											| Out-File -FilePath $OutputFile -append
"-" * ($borderLen)									| Out-File -FilePath $outputFile -append
"TCPIP Networking Information"						| Out-File -FilePath $OutputFile -append
"   1. hostname"									| Out-File -FilePath $OutputFile -append
"   2. ipconfig /allcompartments /all"				| Out-File -FilePath $OutputFile -append
"   3. route print"									| Out-File -FilePath $OutputFile -append
"   4. arp -a"										| Out-File -FilePath $OutputFile -append
"   5. netstat -nato" 								| Out-File -FilePath $OutputFile -append
"   6. netstat -anob"								| Out-File -FilePath $OutputFile -append
"   7. netstat -es" 								| Out-File -FilePath $OutputFile -append
"=" * ($borderLen)									| Out-File -FilePath $outputFile -append
"`n"	| Out-File -FilePath $OutputFile -append
"`n"	| Out-File -FilePath $OutputFile -append
"`n"	| Out-File -FilePath $OutputFile -append
"`n"	| Out-File -FilePath $OutputFile -append
"`n"	| Out-File -FilePath $OutputFile -append

Heading "TCPIP Networking Information"
RunNetCmd "hostname"
# 4/17/14: If WV/WS2008, run "ipconfig /allcompartments /all". If WXP/WS2003 "ipconfig /all".
if ($bn -gt 6000)
{ RunNetCmd "ipconfig" "/allcompartments /all" }
else
{ RunNetCmd "ipconfig" "/all" }
RunNetCmd "route print"
RunNetCmd "arp" "-a"
RunNetCmd "netstat" "-nato"
RunNetCmd "netstat" "-anob"
RunNetCmd "netstat" "-es"
CollectFiles -filesToCollect $outputFile -fileDescription "TCPIP Info" -SectionDescription $sectionDescription

	
	
	
	

#----------Registry (General)
$outputFile = join-path $pwd.path ($ComputerName + "_TCPIP_reg_output.TXT")
$CurrentVersionKeys =	"HKLM\SOFTWARE\Policies\Microsoft\Windows\TCPIP",
						"HKLM\SYSTEM\CurrentControlSet\services\TCPIP",
						"HKLM\SYSTEM\CurrentControlSet\Services\Tcpip6",
						"HKLM\SYSTEM\CurrentControlSet\Services\tcpipreg",
						"HKLM\SYSTEM\CurrentControlSet\Services\iphlpsvc"
RegQuery -RegistryKeys $CurrentVersionKeys -Recursive $true -outputFile $outputFile -fileDescription "TCPIP registry output" -SectionDescription $sectionDescription







#----------TCP OFFLOAD (netsh)
$outputFile = join-path $pwd.path ($ComputerName + "_TCPIP_OFFLOAD.TXT")

"=" * ($borderLen)								| Out-File -FilePath $outputFile -append
"TCPIP Offload Information"						| Out-File -FilePath $OutputFile -append
"=" * ($borderLen)								| Out-File -FilePath $outputFile -append
"Overview"										| Out-File -FilePath $OutputFile -append
"-" * ($borderLen)								| Out-File -FilePath $outputFile -append
"TCPIP Offload Information"						| Out-File -FilePath $OutputFile -append
"  1. netsh int tcp show global"				| Out-File -FilePath $outputFile -Append
"  2. netsh int ipv4 show offload"				| Out-File -FilePath $outputFile -Append
"  3. netstat -nato -p tcp"						| Out-File -FilePath $outputFile -Append
"=" * ($borderLen)								| Out-File -FilePath $outputFile -Append
"`n"	| Out-File -FilePath $OutputFile -append
"`n"	| Out-File -FilePath $OutputFile -append
"`n"	| Out-File -FilePath $OutputFile -append
"`n"	| Out-File -FilePath $OutputFile -append
"`n"	| Out-File -FilePath $OutputFile -append
RunNetCmd "netsh" "int tcp show global"
RunNetCmd "netsh" "int ipv4 show offload"
RunNetCmd "netstat" "-nato -p tcp"

CollectFiles -filesToCollect $outputFile -fileDescription "TCP OFFLOAD" -SectionDescription $sectionDescription




#----------Copy the Services File
$outputFile = join-path $pwd.path ($ComputerName + "_TCPIP_ServicesFile.TXT")

$servicesfile = "$ENV:windir\system32\drivers\etc\services"
if (test-path $servicesfile)
{
  Copy-Item -Path $servicesfile -Destination $outputFile
  CollectFiles -filesToCollect $outputFile -fileDescription "TCPIP Services File" -SectionDescription $sectionDescription
}
else
{
	"$servicesfile Does not exist" | writeto-stdout
}







# W8/WS2012
if ($bn -gt 9000)
{
	"[info]: TCPIP-Component W8/WS2012+" | WriteTo-StdOut

	####################################################
	# TCPIP Transition Technologies
	####################################################
	$outputFile = join-path $pwd.path ($ComputerName + "_TCPIP_info_pscmdlets_net.TXT")


	"=" * ($borderLen)									| Out-File -FilePath $outputFile -append
	"TCPIP Powershell Cmdlets"							| Out-File -FilePath $OutputFile -append
	"=" * ($borderLen)									| Out-File -FilePath $outputFile -append
	"Overview"											| Out-File -FilePath $OutputFile -append
	"-" * ($borderLen)									| Out-File -FilePath $outputFile -append
	"   1. Get-NetCompartment (WS2012+)"				| Out-File -FilePath $OutputFile -append
	"   2. Get-NetIPAddress"							| Out-File -FilePath $OutputFile -append	
	"   3. Get-NetIPInterface"							| Out-File -FilePath $OutputFile -append
	"   4. Get-NetIPConfiguration"						| Out-File -FilePath $OutputFile -append
	"   5. Get-NetIPv4Protocol"							| Out-File -FilePath $OutputFile -append
	"   6. Get-NetIPv6Protocol"							| Out-File -FilePath $OutputFile -append
	"   7. Get-NetOffloadGlobalSetting"					| Out-File -FilePath $OutputFile -append
	"   8. Get-NetPrefixPolicy"							| Out-File -FilePath $OutputFile -append
	"   9. Get-NetRoute -IncludeAllCompartments"		| Out-File -FilePath $OutputFile -append
	"  10. Get-NetTCPConnection"						| Out-File -FilePath $OutputFile -append
	"  10a. GetNetTCPConnEstablished"					| Out-File -FilePath $OutputFile -append
	"  11. Get-NetTransportFilter"						| Out-File -FilePath $OutputFile -append
	"  12. Get-NetTCPSetting"							| Out-File -FilePath $OutputFile -append
	"  13. Get-NetUDPEndpoint"							| Out-File -FilePath $OutputFile -append
	"  14. Get-NetUDPSetting"							| Out-File -FilePath $OutputFile -append
	"=" * ($borderLen)									| Out-File -FilePath $outputFile -append
	"`n"	| Out-File -FilePath $OutputFile -append
	"`n"	| Out-File -FilePath $OutputFile -append
	"`n"	| Out-File -FilePath $OutputFile -append
	"`n"	| Out-File -FilePath $OutputFile -append
	"`n"	| Out-File -FilePath $OutputFile -append

	if ($bn -ge 9600)
	{
		RunPS "Get-NetCompartment"							# W8/WS2012, W8.1/WS2012R2	# fl
	}
	else
	{
		$RunPScmd = "Get-NetCompartment"
		$RunPScmdLength = $RunPScmd.Length
		"-" * ($RunPScmdLength)		| Out-File -FilePath $OutputFile -append
		"$RunPScmd"  				| Out-File -FilePath $OutputFile -append
		"-" * ($RunPScmdLength)  	| Out-File -FilePath $OutputFile -append
		"The Get-NetCompartment pscmdlet is only available in WS2012R2+."	| Out-File -FilePath $OutputFile -append
	}
	RunPS "Get-NetIPAddress"							# W8/WS2012, W8.1/WS2012R2	# fl
	RunPS "Get-NetIPInterface"						-ft	# W8/WS2012, W8.1/WS2012R2	# ft
	RunPS "Get-NetIPConfiguration"						# W8/WS2012, W8.1/WS2012R2	# fl
	RunPS "Get-NetIPv4Protocol"							# W8/WS2012, W8.1/WS2012R2	# fl
	RunPS "Get-NetIPv6Protocol"							# W8/WS2012, W8.1/WS2012R2	# fl
	RunPS "Get-NetOffloadGlobalSetting"					# W8/WS2012, W8.1/WS2012R2	# fl
	RunPS "Get-NetPrefixPolicy"						-ft	# W8/WS2012, W8.1/WS2012R2	# ft
	RunPS "Get-NetRoute -IncludeAllCompartments"	-ft	# W8/WS2012, W8.1/WS2012R2	# ft
	RunPS "Get-NetTCPConnection"					-ft	# W8/WS2012, W8.1/WS2012R2	# ft
	RunPS "GetNetTCPConnEstablished"				-ft	# 
	RunPS "Get-NetTransportFilter"						# W8/WS2012, W8.1/WS2012R2	# fl
	RunPS "Get-NetTCPSetting"							# W8/WS2012, W8.1/WS2012R2	# fl
	RunPS "Get-NetUDPEndpoint"						-ft	# W8/WS2012, W8.1/WS2012R2	# ft
	RunPS "Get-NetUDPSetting"							# W8/WS2012, W8.1/WS2012R2	# fl

	CollectFiles -filesToCollect $outputFile -fileDescription "TCPIP Net Powershell Cmdlets" -SectionDescription $sectionDescription
}


# W8/WS2012
if ($bn -gt 9000)
{
	####################################################
	# TCPIP IPv6 Transition Technologies
	####################################################
	$outputFile = join-path $pwd.path ($ComputerName + "_TCPIP_info_pscmdlets_IPv6Transition.TXT")
	"=" * ($borderLen)									| Out-File -FilePath $outputFile -append
	"IPv6 Transition Technologies Powershell Cmdlets"	| Out-File -FilePath $OutputFile -append
	"=" * ($borderLen)									| Out-File -FilePath $outputFile -append
	"Overview"											| Out-File -FilePath $OutputFile -append
	"-" * ($borderLen)									| Out-File -FilePath $outputFile -append
	"   1. Get-Net6to4Configuration"					| Out-File -FilePath $OutputFile -append
	"   2. Get-NetDnsTransitionConfiguration"			| Out-File -FilePath $OutputFile -append
	"   3. Get-NetDnsTransitionMonitoring"				| Out-File -FilePath $OutputFile -append
	"   4. Get-NetIPHttpsConfiguration"					| Out-File -FilePath $OutputFile -append
	"   5. Get-NetIsatapConfiguration"					| Out-File -FilePath $OutputFile -append
	"   6. Get-NetNatTransitionConfiguration"			| Out-File -FilePath $OutputFile -append
	"   7. Get-NetNatTransitionMonitoring"				| Out-File -FilePath $OutputFile -append
	"   8. Get-NetTeredoConfiguration"					| Out-File -FilePath $OutputFile -append
	"   9. Get-NetTeredoState"							| Out-File -FilePath $OutputFile -append
	"=" * ($borderLen)									| Out-File -FilePath $outputFile -append
	"`n"	| Out-File -FilePath $OutputFile -append
	"`n"	| Out-File -FilePath $OutputFile -append
	"`n"	| Out-File -FilePath $OutputFile -append
	"`n"	| Out-File -FilePath $OutputFile -append
	"`n"	| Out-File -FilePath $OutputFile -append

	#Get role, OSVer, hotfix data.
	$cs =  gwmi -Namespace "root\cimv2" -class win32_computersystem -ComputerName $ComputerName
	$DomainRole = $cs.domainrole
	
	if ($cs.DomainRole -ge 2)	
	{
		RunPS "Get-Net6to4Configuration"				# W8/WS2012, W8.1/WS2012R2	#fl
		RunPS "Get-NetDnsTransitionConfiguration"		# W8/WS2012, W8.1/WS2012R2	#fl		# server only
		RunPS "Get-NetDnsTransitionMonitoring"			# W8/WS2012, W8.1/WS2012R2	#fl 	# server only
	}
	else
	{
		"------------------------" 									| Out-File -FilePath $outputFile -append
		"Get-Net6to4Configuration"	| Out-File -FilePath $OutputFile -append
		"------------------------" 									| Out-File -FilePath $outputFile -append
		"Not running pscmdlet on non-server SKUs." | Out-File -FilePath $OutputFile -append
		"`n"	| Out-File -FilePath $OutputFile -append
		"`n"	| Out-File -FilePath $OutputFile -append
		"`n"	| Out-File -FilePath $OutputFile -append
		"---------------------------------" | Out-File -FilePath $outputFile -append
		"Get-NetDnsTransitionConfiguration" | Out-File -FilePath $OutputFile -append
		"---------------------------------" | Out-File -FilePath $outputFile -append
		"Not running pscmdlet on non-server SKUs."	| Out-File -FilePath $OutputFile -append
		"`n"	| Out-File -FilePath $OutputFile -append
		"`n"	| Out-File -FilePath $OutputFile -append
		"`n"	| Out-File -FilePath $OutputFile -append
		"------------------------------" | Out-File -FilePath $outputFile -append
		"Get-NetDnsTransitionMonitoring" | Out-File -FilePath $OutputFile -append
		"------------------------------" | Out-File -FilePath $outputFile -append
		"Not running pscmdlet on non-server SKUs."	| Out-File -FilePath $OutputFile -append
		"`n"	| Out-File -FilePath $OutputFile -append
		"`n"	| Out-File -FilePath $OutputFile -append
		"`n"	| Out-File -FilePath $OutputFile -append
	}
	RunPS "Get-NetIPHttpsConfiguration"					# W8/WS2012, W8.1/WS2012R2	#fl
	RunPS "Get-NetIPHttpsState"							# W8/WS2012, W8.1/WS2012R2	#fl
	RunPS "Get-NetIsatapConfiguration"					# W8/WS2012, W8.1/WS2012R2	#fl
	
	if ($cs.DomainRole -ge 2)	
	{
		RunPS "Get-NetNatTransitionConfiguration"		# W8/WS2012, W8.1/WS2012R2	#fl 	#server only
		RunPS "Get-NetNatTransitionMonitoring"		-ft	# W8/WS2012, W8.1/WS2012R2	#ft		#server only
	}
	else
	{
		"---------------------------------" 		| Out-File -FilePath $outputFile -append
		"Get-NetNatTransitionConfiguration"	| Out-File -FilePath $OutputFile -append
		"---------------------------------" 		| Out-File -FilePath $outputFile -append
		"Not running pscmdlet on non-server SKUs." | Out-File -FilePath $OutputFile -append
		"`n"	| Out-File -FilePath $OutputFile -append
		"`n"	| Out-File -FilePath $OutputFile -append
		"`n"	| Out-File -FilePath $OutputFile -append
		"------------------------------" 		| Out-File -FilePath $outputFile -append
		"Get-NetNatTransitionMonitoring"			| Out-File -FilePath $OutputFile -append
		"------------------------------" 		| Out-File -FilePath $outputFile -append
		"Not running pscmdlet on non-server SKUs."	| Out-File -FilePath $OutputFile -append
		"`n"	| Out-File -FilePath $OutputFile -append
		"`n"	| Out-File -FilePath $OutputFile -append
		"`n"	| Out-File -FilePath $OutputFile -append
	}
	RunPS "Get-NetTeredoConfiguration"					# W8/WS2012, W8.1/WS2012R2	#fl
	RunPS "Get-NetTeredoState"							# W8/WS2012, W8.1/WS2012R2	#fl

	CollectFiles -filesToCollect $outputFile -fileDescription "TCPIP IPv6 Transition Technology Info" -SectionDescription $sectionDescription	
}



#V/WS2008+
if ($bn -gt 6000)
{
	"[info]: TCPIP-Component WV/WS2008+" | WriteTo-StdOut
	$outputFile = join-path $pwd.path ($ComputerName + "_TCPIP_netsh_info.TXT")

	"=" * ($borderLen)									| Out-File -FilePath $outputFile -append
	"TCPIP Netsh Commands"								| Out-File -FilePath $OutputFile -append
	"=" * ($borderLen)									| Out-File -FilePath $outputFile -append
	"Overview"											| Out-File -FilePath $OutputFile -append
	"-" * ($borderLen)									| Out-File -FilePath $outputFile -append
	"TCP Netsh Commands"								| Out-File -FilePath $OutputFile -append
	"   1. netsh int tcp show global"					| Out-File -FilePath $OutputFile -append
	"   2. netsh int tcp show heuristics"						| Out-File -FilePath $OutputFile -append
	"   3. netsh int tcp show chimneyapplications"		| Out-File -FilePath $OutputFile -append
	"   4. netsh int tcp show chimneyports"				| Out-File -FilePath $OutputFile -append
	"   5. netsh int tcp show chimneystats"				| Out-File -FilePath $OutputFile -append
	"   6. netsh int tcp show netdmastats"				| Out-File -FilePath $OutputFile -append
	"   7. netsh int tcp show rscstats"					| Out-File -FilePath $OutputFile -append
	"   8. netsh int tcp show security"					| Out-File -FilePath $OutputFile -append
	"   9. netsh int tcp show supplemental"				| Out-File -FilePath $OutputFile -append
	"  10. netsh int tcp show supplementalports"		| Out-File -FilePath $OutputFile -append
	"  11. netsh int tcp show supplementalsubnets"		| Out-File -FilePath $OutputFile -append
	"-" * ($borderLen)									| Out-File -FilePath $outputFile -append
	"IPv4 Netsh Commands"								| Out-File -FilePath $OutputFile -append
	"   1. netsh int show int"							| Out-File -FilePath $OutputFile -append
	"   2. netsh int ipv4 show int"						| Out-File -FilePath $OutputFile -append
	"   3. netsh int ipv4 show addresses"				| Out-File -FilePath $OutputFile -append
	"   4. netsh int ipv4 show ipaddresses"				| Out-File -FilePath $OutputFile -append
	"   5. netsh int ipv4 show compartments"			| Out-File -FilePath $OutputFile -append
	"   6. netsh int ipv4 show dnsservers"				| Out-File -FilePath $OutputFile -append
	"   7. netsh int ipv4 show winsservers"				| Out-File -FilePath $OutputFile -append
	"   8. netsh int ipv4 show dynamicportrange tcp"	| Out-File -FilePath $OutputFile -append
	"   9. netsh int ipv4 show dynamicportrange udp"	| Out-File -FilePath $OutputFile -append
	"  10. netsh int ipv4 show global"					| Out-File -FilePath $OutputFile -append
	"  11. netsh int ipv4 show icmpstats"				| Out-File -FilePath $OutputFile -append
	"  12. netsh int ipv4 show ipstats"					| Out-File -FilePath $OutputFile -append
	"  13. netsh int ipv4 show joins"					| Out-File -FilePath $OutputFile -append
	"  14. netsh int ipv4 show offload"					| Out-File -FilePath $OutputFile -append
	"  15. netsh int ipv4 show route"					| Out-File -FilePath $OutputFile -append
	"  16. netsh int ipv4 show subint"					| Out-File -FilePath $OutputFile -append
	"  17. netsh int ipv4 show tcpconnections"			| Out-File -FilePath $OutputFile -append
	"  18. netsh int ipv4 show tcpstats"				| Out-File -FilePath $OutputFile -append
	"  19. netsh int ipv4 show udpconnections"			| Out-File -FilePath $OutputFile -append
	"  20. netsh int ipv4 show udpstats"				| Out-File -FilePath $OutputFile -append
	"  21. netsh int ipv4 show destinationcache"		| Out-File -FilePath $OutputFile -append
	"  22. netsh int ipv4 show ipnettomedia"			| Out-File -FilePath $OutputFile -append
	"  23. netsh int ipv4 show neighbors"				| Out-File -FilePath $OutputFile -append
	"-" * ($borderLen)									| Out-File -FilePath $outputFile -append
	"IPv6 Netsh Commands"								| Out-File -FilePath $OutputFile -append
	"   1. netsh int show int"							| Out-File -FilePath $OutputFile -append	
	"   2. netsh int ipv6 show int"						| Out-File -FilePath $OutputFile -append
	"   3. netsh int ipv6 show addresses"				| Out-File -FilePath $OutputFile -append
	"   4. netsh int ipv6 show compartments"			| Out-File -FilePath $OutputFile -append
	"   5. netsh int ipv6 show destinationcache"		| Out-File -FilePath $OutputFile -append
	"   6. netsh int ipv6 show dnsservers"				| Out-File -FilePath $OutputFile -append
	"   7. netsh int ipv6 show dynamicportrange tcp"	| Out-File -FilePath $OutputFile -append
	"   8. netsh int ipv6 show dynamicportrange udp"	| Out-File -FilePath $OutputFile -append
	"   9. netsh int ipv6 show global"					| Out-File -FilePath $OutputFile -append
	"  10. netsh int ipv6 show ipstats"					| Out-File -FilePath $OutputFile -append
	"  11. netsh int ipv6 show joins"					| Out-File -FilePath $OutputFile -append
	"  12. netsh int ipv6 show neighbors"				| Out-File -FilePath $OutputFile -append
	"  13. netsh int ipv6 show offload"					| Out-File -FilePath $OutputFile -append
	"  14. netsh int ipv6 show potentialrouters"		| Out-File -FilePath $OutputFile -append
	"  15. netsh int ipv6 show prefixpolicies"			| Out-File -FilePath $OutputFile -append
	"  16. netsh int ipv6 show privacy"					| Out-File -FilePath $OutputFile -append
	"  17. netsh int ipv6 show route"					| Out-File -FilePath $OutputFile -append
	"  18. netsh int ipv6 show siteprefixes"			| Out-File -FilePath $OutputFile -append
	"  19. netsh int ipv6 show subint"					| Out-File -FilePath $OutputFile -append
	"  20. netsh int ipv6 show tcpstats"				| Out-File -FilePath $OutputFile -append
	"  21. netsh int ipv6 show teredo"					| Out-File -FilePath $OutputFile -append
	"  22. netsh int ipv6 show udpstats"				| Out-File -FilePath $OutputFile -append
	"-" * ($borderLen)									| Out-File -FilePath $outputFile -append
	"IPv6 Transition Technologies"						| Out-File -FilePath $OutputFile -append
	"   1. netsh int ipv6 show int"						| Out-File -FilePath $OutputFile -append
	"   2. netsh int 6to4 show int"						| Out-File -FilePath $OutputFile -append
	"   3. netsh int 6to4 show relay"					| Out-File -FilePath $OutputFile -append
	"   4. netsh int 6to4 show routing"					| Out-File -FilePath $OutputFile -append
	"   5. netsh int 6to4 show state"					| Out-File -FilePath $OutputFile -append
	"   6. netsh int httpstunnel show interfaces"		| Out-File -FilePath $OutputFile -append
	"   7. netsh int httpstunnel show statistics"		| Out-File -FilePath $OutputFile -append
	"   8. netsh int isatap show router"				| Out-File -FilePath $OutputFile -append
	"   9. netsh int isatap show state"					| Out-File -FilePath $OutputFile -append
	"  10. netsh int teredo show state"					| Out-File -FilePath $OutputFile -append
	"  11. netsh int ipv6 show int level=verbose"		| Out-File -FilePath $OutputFile -append
	"-" * ($borderLen)									| Out-File -FilePath $outputFile -append
	"NetIO Netsh Commands"								| Out-File -FilePath $OutputFile -append
	"   1. netio show bindingfilters"					| Out-File -FilePath $OutputFile -append
	"-" * ($borderLen)									| Out-File -FilePath $outputFile -append
	"PortProxy"	| Out-File -FilePath $OutputFile -append
	"   1. netsh int portproxy show all"	| Out-File -FilePath $OutputFile -append
	"=" * ($borderLen)									| Out-File -FilePath $outputFile -append
	"`n"	| Out-File -FilePath $OutputFile -append
	"`n"	| Out-File -FilePath $OutputFile -append
	"`n"	| Out-File -FilePath $OutputFile -append
	"`n"	| Out-File -FilePath $OutputFile -append
	"`n"	| Out-File -FilePath $OutputFile -append
	

	Heading "TCP Netsh Commands"
	RunNetCmd "netsh" "int tcp show global"
	RunNetCmd "netsh" "int tcp show heuristics"
	RunNetCmd "netsh" "int tcp show chimneyapplications"
	RunNetCmd "netsh" "int tcp show chimneyports"
	RunNetCmd "netsh" "int tcp show chimneystats"
	RunNetCmd "netsh" "int tcp show netdmastats"
	RunNetCmd "netsh" "int tcp show rscstats"
	RunNetCmd "netsh" "int tcp show security"
	RunNetCmd "netsh" "int tcp show supplemental"
	RunNetCmd "netsh" "int tcp show supplementalports"
	RunNetCmd "netsh" "int tcp show supplementalsubnets"

	Heading "IPv4 Netsh Commands"
	RunNetCmd "netsh" "int show int"
	RunNetCmd "netsh" "int ipv4 show int"
	RunNetCmd "netsh" "int ipv4 show addresses"
	RunNetCmd "netsh" "int ipv4 show ipaddresses"
	RunNetCmd "netsh" "int ipv4 show compartments"
	RunNetCmd "netsh" "int ipv4 show dnsservers"
	RunNetCmd "netsh" "int ipv4 show winsservers"
	RunNetCmd "netsh" "int ipv4 show dynamicportrange tcp"
	RunNetCmd "netsh" "int ipv4 show dynamicportrange udp"
	RunNetCmd "netsh" "int ipv4 show global"
	RunNetCmd "netsh" "int ipv4 show icmpstats"
	RunNetCmd "netsh" "int ipv4 show ipstats"
	RunNetCmd "netsh" "int ipv4 show joins"
	RunNetCmd "netsh" "int ipv4 show offload"
	RunNetCmd "netsh" "int ipv4 show route"
	RunNetCmd "netsh" "int ipv4 show subint"
	RunNetCmd "netsh" "int ipv4 show tcpconnections"
	RunNetCmd "netsh" "int ipv4 show tcpstats"
	RunNetCmd "netsh" "int ipv4 show udpconnections"
	RunNetCmd "netsh" "int ipv4 show udpstats"
	RunNetCmd "netsh" "int ipv4 show destinationcache"
	RunNetCmd "netsh" "int ipv4 show ipnettomedia"
	RunNetCmd "netsh" "int ipv4 show neighbors"

	Heading "IPv6 Netsh Commands"
	RunNetCmd "netsh" "int show int"
	RunNetCmd "netsh" "int ipv6 show int"
	RunNetCmd "netsh" "int ipv6 show addresses"
	RunNetCmd "netsh" "int ipv6 show compartments"
	RunNetCmd "netsh" "int ipv6 show destinationcache"
	RunNetCmd "netsh" "int ipv6 show dnsservers"
	RunNetCmd "netsh" "int ipv6 show dynamicportrange tcp"
	RunNetCmd "netsh" "int ipv6 show dynamicportrange udp"
	RunNetCmd "netsh" "int ipv6 show global"
	RunNetCmd "netsh" "int ipv6 show ipstats"
	RunNetCmd "netsh" "int ipv6 show joins"
	RunNetCmd "netsh" "int ipv6 show neighbors"
	RunNetCmd "netsh" "int ipv6 show offload"
	RunNetCmd "netsh" "int ipv6 show potentialrouters"
	RunNetCmd "netsh" "int ipv6 show prefixpolicies"
	RunNetCmd "netsh" "int ipv6 show privacy"
	RunNetCmd "netsh" "int ipv6 show route"
	RunNetCmd "netsh" "int ipv6 show siteprefixes"
	RunNetCmd "netsh" "int ipv6 show siteprefixes"
	RunNetCmd "netsh" "int ipv6 show subint"
	RunNetCmd "netsh" "int ipv6 show tcpstats"
	RunNetCmd "netsh" "int ipv6 show teredo"
	RunNetCmd "netsh" "int ipv6 show udpstats"
	
	Heading "IPv6 Transition Technologies"
	RunNetCmd "netsh" "int ipv6 show int"
	RunNetCmd "netsh" "int 6to4 show int"
	RunNetCmd "netsh" "int 6to4 show relay"
	RunNetCmd "netsh" "int 6to4 show routing"
	RunNetCmd "netsh" "int 6to4 show state"
	RunNetCmd "netsh" "int httpstunnel show interfaces"
	RunNetCmd "netsh" "int httpstunnel show statistics"
	RunNetCmd "netsh int isatap show router"
	RunNetCmd "netsh int isatap show state"	
	RunNetCmd "netsh int teredo show state"	
	RunNetCmd "netsh" "int ipv6 show int level=verbose"

	Heading "NetIO Netsh Commands"
	RunNetCmd "netsh" "netio show bindingfilters"

	Heading "PortProxy"
	RunNetCmd "netsh" "int portproxy show all"
	
	CollectFiles -filesToCollect $outputFile -fileDescription "TCPIP netsh output" -SectionDescription $sectionDescription

	#----------Iphlpsvc EventLog
	#----------WLAN Autoconfig EventLog
	#Iphlpsvc
	$EventLogNames = @()
	$EventLogNames += "Microsoft-Windows-Iphlpsvc/Operational"
	$EventLogNames += "Microsoft-Windows-WLAN-AutoConfig/Operational"

	$Prefix = ""
	$Suffix = "_evt_"
	.\TS_GetEvents.ps1 -EventLogNames $EventLogNames -SectionDescription $sectionDescription -Prefix $Prefix -Suffix $Suffix

}
else # XP/WS2003
{
	"[info]: TCPIP-Component XP/WS2003+" | WriteTo-StdOut
	$outputFile = join-path $pwd.path ($ComputerName + "_TCPIP_netsh_info.TXT")
	
	#----------Netsh for IP (XP/W2003)
	"`n`n`n`n`n" + "=" * (50) + "`r`n[NETSH INT IP]`r`n" + "=" * (50) | Out-File -FilePath $outputFile -Append
	"`n`n"
	"`n" + "-" * (50) + "`r`n[netsh int ipv4 show output]`r`n" + "-" * (50) | Out-File -FilePath $outputFile -Append
	RunNetCmd "netsh" "int show int"
	RunNetCmd "netsh" "int ip show int"
	RunNetCmd "netsh" "int ip show address"
	RunNetCmd "netsh" "int ip show config"
	RunNetCmd "netsh" "int ip show dns"
	RunNetCmd "netsh" "int ip show joins"
	RunNetCmd "netsh" "int ip show offload"
	RunNetCmd "netsh" "int ip show wins"

	# If RRAS is running, run the following commands
	if ((Get-Service "remoteaccess").Status -eq 'Running')
	{
		RunNetCmd "netsh" "int ip show icmp"
		RunNetCmd "netsh" "int ip show interface"
		RunNetCmd "netsh" "int ip show ipaddress"
		RunNetCmd "netsh" "int ip show ipnet"
		RunNetCmd "netsh" "int ip show ipstats"
		RunNetCmd "netsh" "int ip show tcpconn"
		RunNetCmd "netsh" "int ip show tcpstats"
		RunNetCmd "netsh" "int ip show udpconn"
		RunNetCmd "netsh" "int ip show udpstats"
	}
	CollectFiles -filesToCollect $outputFile -fileDescription "TCPIP netsh output" -SectionDescription $sectionDescription
}

"[info]:TCPIP-Component:END" | WriteTo-StdOut



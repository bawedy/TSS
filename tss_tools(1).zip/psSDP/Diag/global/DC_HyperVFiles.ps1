﻿#_# 2021-02-02 WalterE

$vmmskey = "HKLM:\SYSTEM\CurrentControlSet\Services\vmms"
            
if (Test-Path $vmmskey) 
{ 

	Import-LocalizedData -BindingVariable HyperVStrings

	Write-DiagProgress -Activity $HyperVStrings.ID_HyperVInfo -Status $HyperVStrings.ID_HyperVInfoDesc

	#Virtual Machine XML Files
	$SourceXMLFiles= $Env:ProgramData + "\Microsoft\Windows\Hyper-V\Virtual Machines\*.xml"
	
	Get-ChildItem $SourceXMLFiles |  ForEach-Object {
		$XMLFileName = Split-Path $_.Name -leaf
		$XMLFullPath = $_.FullName
		$VMGUID = $XMLFileName.Substring(0, $XMLFileName.Length -4)
		$objWMI = Get-WmiObject -Query "Select * from Msvm_ComputerSystem where Name = `'$VMGUID`'" -Namespace root\virtualization
		$VMName = $HyperVStrings.ID_HyperVVMXMLOutputUnknown
		$objWMI | ForEach-Object {
			$VMName = $_.ElementName
		}
		$filesToCollect = $XMLFullPath
		$filesDescription = $VMName
		$sectionDescription = $HyperVStrings.ID_HyperVVMXMLFiles
		
		CollectFiles -filesToCollect $filesToCollect -fileDescription $filesDescription -sectionDescription $sectionDescription -renameOutput $true
	}
	
	#Hyper-V Event Logs
	
	$EventLogNames = wevtutil.exe el | Select-String "Microsoft-Windows-Hyper-V"
	$EventLogNames += "Microsoft-Windows-VHDMP/Operational"
	
	#_# Add Shielded VM Event Logs
	$EventLogNamesHGS = wevtutil.exe el | Select-String "Microsoft-Windows-HostGuardianService"
	$EventLogNamesHGC = wevtutil.exe el | Select-String "Microsoft-Windows-HostGuardianClient"
	$EventLogNames += $EventLogNamesHGS
	$EventLogNames += $EventLogNamesHGC
	
	if ($EventLogNames -ne $null) {
		[array] $OutputFormats = "txt", "evtx", "etl", "csv"
		Run-DiagExpression .\TS_GetEvents.ps1 -EventLogNames $EventLogNames -sectionDescription $HyperVStrings.ID_HyperVEventLogOutput -OutputFormats $OutputFormats
	} else {
		$HyperV_Summary = new-object PSObject
		add-member -inputobject $HyperV_Summary -membertype noteproperty -name "Hyper-V Event Logs" -value "There are no Hyper-V event logs on this computer"
		$HyperV_Summary | convertto-xml | update-diagreport -id $HyperVStrings.ID_HyperVEventLogOutput -name $HyperVStrings.ID_HyperVEventLogOutput -verbosity informational
	}
}

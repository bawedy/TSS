﻿#************************************************
# DC_NetworkingDiagnostic.ps1
# Version 1.0.2006: The Networking Diagnostic was created in 2006 with SDPv1 and SDPv2.
# Version 1.1.2009: The Networking Diagnostic was moved to SDP3.
# Version 1.2.2009-2014: Many updates to all the static data collection scripts.
# Version 2.0.08.27.14: Republish 05.03.19.
# Date: 2006-2019
# Author: Boyd Benson (bbenson@microsoft.com) +WalterE
# Description: Creates an output file showing the version of the Networking Diagnostic
# Called from: Networking Diagnostic, psSDP: all TS_AutoAddCommands_*
#*******************************************************
# 2019-06-11 WalterE added to psSDP #_#

Trap [Exception]
	{
	 # Handle exception and throw it to the stdout log file. Then continue with function and script.
		 $Script:ExceptionMessage = $_
		 "[info]: Exception occurred."  | WriteTo-StdOut
		 "[info]: Exception.Message $ExceptionMessage."  | WriteTo-StdOut 
		 $Error.Clear()
		 continue
	}

Import-LocalizedData -BindingVariable ScriptVariable

$sectionDescription = "Diagnostic Version"

# detect OS version and SKU
$wmiOSVersion = gwmi -Namespace "root\cimv2" -Class Win32_OperatingSystem
[int]$bn = [int]$wmiOSVersion.BuildNumber
$sku = $((gwmi win32_operatingsystem).OperatingSystemSKU)
$domainRole = (Get-WmiObject -Class Win32_ComputerSystem).DomainRole	# 0 or 1: client; >1: server


function GetOsVerName($bn)
{
	switch ($bn)
	{ # 	:: 10.0 - Windows 10		10240 RTM, 10586 TH2 v1511, 14393 RS1 v1607, 15063 RS2 v1703, 16299 RS3 1709, 17134 RS4 1803, 17763 RS5 1809, 18362 19H1 1903, 18363 19H2 1909
		18363 {return "W10v1909"}
		18362 {return "W10v1903/WS2019"}
		17763 {return "W10v1809"}
		17134 {return "W10v1803"}
		16299 {return "W10v1709"}
		15063 {return "W10v1703"}
		14393 {return "W10v1607/WS2016"}
		10586 {return "W10v1511"}
		10240 {return "W10rtm"}		
		9600  {return "W8.1/WS2012R2"}
		9200  {return "W8/WS2012"}
		7601  {return "W7/WS2008R2 SP1"}
		7600  {return "W7/WS2008R2 RTM"}
		default {return "unknown-OS"}
	}
}

function GetOsSkuName($sku)
{
	switch ($sku)
	{
		# GetProductInfo function
		# http://msdn.microsoft.com/en-us/library/ms724358.aspx
		#
		0  {return ""}
		1  {return "Ultimate Edition"}
		2  {return "Home Basic Edition"}
		3  {return "Home Basic Premium Edition"}
		4  {return "Enterprise Edition"}
		5  {return "Home Basic N Edition"}
		6  {return "Business Edition"}
		7  {return "Standard Server Edition"}
		8  {return "Datacenter Server Edition"}
		9  {return "Small Business Server Edition"}
		10 {return "Enterprise Server Edition"}
		11 {return "Starter Edition"}
		12 {return "Datacenter Server Core Edition"}
		13 {return "Standard Server Core Edition"}
		14 {return "Enterprise Server Core Edition"}
		15 {return "Enterprise Server Edition for Itanium-Based Systems"}
		16 {return "Business N Edition"}
		17 {return "Web Server Edition"}
		18 {return "Cluster Server Edition"}
		19 {return "Home Server Edition"}
		20 {return "Storage Express Server Edition"}
		21 {return "Storage Standard Server Edition"}
		22 {return "Storage Workgroup Server Edition"}
		23 {return "Storage Enterprise Server Edition"}
		24 {return "Server For Small Business Edition"}
		25 {return "Small Business Server Premium Edition"} # 0x00000019
		26 {return "Home Premium N Edition"} # 0x0000001a
		27 {return "Enterprise N Edition"} # 0x0000001b
		28 {return "Ultimate N Edition"} # 0x0000001c
		29 {return "Web Server Edition (core installation)"} # 0x0000001d
		30 {return "Windows Essential Business Server Management Server"} # 0x0000001e
		31 {return "Windows Essential Business Server Security Server"} # 0x0000001f
		32 {return "Windows Essential Business Server Messaging Server"} # 0x00000020
		33 {return "Server Foundation"} # 0x00000021
		34 {return "Windows Home Server 2011"} # 0x00000022 not found
		35 {return "Windows Server 2008 without Hyper-V for Windows Essential Server Solutions"} # 0x00000023
		36 {return "Server Standard Edition without Hyper-V (full installation)"} # 0x00000024
		37 {return "Server Datacenter Edition without Hyper-V (full installation)"} # 0x00000025
		38 {return "Server Enterprise Edition without Hyper-V (full installation)"} # 0x00000026
		39 {return "Server Datacenter Edition without Hyper-V (core installation)"} # 0x00000027
		40 {return "Server Standard Edition without Hyper-V (core installation)"} # 0x00000028
		41 {return "Server Enterprise Edition without Hyper-V (core installation)"} # 0x00000029
		42 {return "Microsoft Hyper-V Server"} # 0x0000002a
		43 {return "Storage Server Express (core installation)"} # 0x0000002b
		44 {return "Storage Server Standard (core installation)"} # 0x0000002c
		45 {return "Storage Server Workgroup (core installation)"} # 0x0000002d
		46 {return "Storage Server Enterprise (core installation)"} # 0x0000002e
		47 {return "Starter N"} # 0x0000002f
		48 {return "Professional Edition"} #0x00000030
		49 {return "ProfessionalN Edition"} #0x00000031
		50 {return "Windows Small Business Server 2011 Essentials"} #0x00000032
		51 {return "Server For SB Solutions"} #0x00000033
		52 {return "Server Solutions Premium"} #0x00000034
		53 {return "Server Solutions Premium (core installation)"} #0x00000035
		54 {return "Server For SB Solutions EM"} #0x00000036
		55 {return "Server For SB Solutions EM"} #0x00000037
		55 {return "Windows MultiPoint Server"} #0x00000038
		#not found: 3a
		59 {return "Windows Essential Server Solution Management"} #0x0000003b
		60 {return "Windows Essential Server Solution Additional"} #0x0000003c
		61 {return "Windows Essential Server Solution Management SVC"} #0x0000003d
		62 {return "Windows Essential Server Solution Additional SVC"} #0x0000003e
		63 {return "Small Business Server Premium (core installation)"} #0x0000003f
		64 {return "Server Hyper Core V"} #0x00000040
		 #0x00000041 not found
		 #0x00000042-48 not supported
		76 {return "Windows MultiPoint Server Standard (full installation)"} #0x0000004C
		77 {return "Windows MultiPoint Server Premium (full installation)"} #0x0000004D
		79 {return "Server Standard (evaluation installation)"} #0x0000004F
		80 {return "Server Datacenter (evaluation installation)"} #0x00000050
		84 {return "Enterprise N (evaluation installation)"} #0x00000054
		95 {return "Storage Server Workgroup (evaluation installation)"} #0x0000005F
		96 {return "Storage Server Standard (evaluation installation)"} #0x00000060
		98 {return "Windows 8 N"} #0x00000062
		99 {return "Windows 8 China"} #0x00000063
		100 {return "Windows 8 Single Language"} #0x00000064
		101 {return "Windows 8"} #0x00000065
		102 {return "Professional with Media Center"} #0x00000067
	}	
}

$osVerName = GetOsVerName $bn
$osSkuName = GetOsSkuName $sku

$OutputFile= "_psSDP_DiagnosticVersion.TXT"
"`n"												| Out-File -FilePath $OutputFile -append
"Diagnostic  : psSDP Diagnostic v$global:VerDate"	| Out-File -FilePath $OutputFile -append
"Publish Date: $global:Publish_Date"				| Out-File -FilePath $OutputFile -append
"`n"												| Out-File -FilePath $OutputFile -append
if ($domainRole -gt 1) {$Server_Client = "Server"
} else { $Server_Client = "Client"}
"Type                         : $Server_Client"			| Out-File -FilePath $OutputFile -append
"Operating System Name        : $osVerName" 			| Out-File -FilePath $OutputFile -Append
"Operating System SKU         : $osSkuName" 			| Out-File -FilePath $OutputFile -Append
"Operating System Build Number: $bn" 					| Out-File -FilePath $OutputFile -Append
"`n"													| Out-File -FilePath $OutputFile -append
"`n"													| Out-File -FilePath $OutputFile -append
"`n Powershell version:"								| Out-File -FilePath $OutputFile -append
$PSVersionTable	| ft -AutoSize							| Out-File -FilePath $OutputFile -append
"`n ExecutionPolicy:"									| Out-File -FilePath $OutputFile -append
Get-ExecutionPolicy -List 								| Out-File -FilePath $OutputFile -append
CollectFiles -filesToCollect $OutputFile -fileDescription "Diagnostic Version" -SectionDescription $sectionDescription	

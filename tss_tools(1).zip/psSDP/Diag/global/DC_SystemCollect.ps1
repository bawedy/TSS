﻿#************************************************
# DC_SystemCollect.ps1
# Version 1.1
# Date: 2009-2019
# Author: Walter Eder (waltere@microsoft.com)
# Description: Collects additional System information and ETL Logs (tbd).
# Called from: TS_AutoAddCommands_Apps.ps1
#*******************************************************

Trap [Exception]
	{
	 # Handle exception and throw it to the stdout log file. Then continue with function and script.
		 $Script:ExceptionMessage = $_
		 "[info]: Exception occurred."  | WriteTo-StdOut
		 "[info]: Exception.Message $ExceptionMessage."  | WriteTo-StdOut 
		 $Error.Clear()
		 continue
		 # later use return to return the exception message to an object:   return $Script:ExceptionMessage
	}

Write-verbose "$(Get-Date -UFormat "%R:%S") : Start of script DC_SystemCollect.ps1"
"==================== Starting DC_SystemCollect.ps1 script ====================" | WriteTo-StdOut
#_# Import-LocalizedData -BindingVariable ScriptStrings

# Registry keys
"Getting System Registry Keys" | WriteTo-StdOut
Write-DiagProgress -Activity $ScriptStrings.ID_SystemFiles_Title -Status "Registry keys"

$Regkeys = "HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System"
$OutputFile = $ComputerName + "_reg_SystemPolicies_HKLM.txt"
RegQuery -RegistryKeys $Regkeys -Recursive $true -OutputFile $OutputFile -fileDescription "System Policies Registry Key" -SectionDescription "Software Registry keys"

$Regkeys = "HKEY_LOCAL_MACHINE\Software\Microsoft\Windows NT\CurrentVersion\Image File Execution Options", "HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Internet Settings"
$OutputFile = $ComputerName + "_reg_ImageFileExecutionRegistry.txt"
RegQuery -RegistryKeys $Regkeys -Recursive $true -OutputFile $OutputFile -fileDescription "ImageFileExecution Registry Key" -SectionDescription "Software Registry keys"

$Regkeys = "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\MUI\UILanguages" 
$OutputFile = $ComputerName + "_reg_UILanguages_HKLM.txt"
RegQuery -RegistryKeys $Regkeys -Recursive $true -OutputFile $OutputFile -fileDescription "UI Languages Registry Key" -SectionDescription "Software Registry keys"

$Regkeys = "HKEY_LOCAL_MACHINE\SYSTEM\WPA" 
$OutputFile = $ComputerName + "_reg_WPA_HKLM.txt"
RegQuery -RegistryKeys $Regkeys -Recursive $true -OutputFile $OutputFile -fileDescription "WPA Registry Key" -SectionDescription "Software Registry keys"

$Regkeys = "HKCU\Software\Microsoft\Windows\CurrentVersion\DeviceAccess", "HKLM\Software\Microsoft\Windows\CurrentVersion\DeviceAccess" 
$OutputFile = $ComputerName + "_reg_DeviceAccess.txt"
RegQuery -RegistryKeys $Regkeys -Recursive $true -OutputFile $OutputFile -fileDescription "Device Access Registry Key" -SectionDescription "Software Registry keys"

$Regkeys = "HKCU\Software\Classes\ActivatableClasses", "HKLM\Software\Classes\ActivatableClasses" 
$OutputFile = $ComputerName + "_reg_ActivatableClasses.txt"
RegQuery -RegistryKeys $Regkeys -Recursive $true -OutputFile $OutputFile -fileDescription "Activatable Classes Registry Key" -SectionDescription "Software Registry keys"
    
$Regkeys = "HKCU\Software\Classes\Extensions" 
$OutputFile = $ComputerName + "_reg_Extensions_HKCU.txt"
RegQuery -RegistryKeys $Regkeys -Recursive $true -OutputFile $OutputFile -fileDescription "Extensions Registry Key" -SectionDescription "Software Registry keys"
  
# Licensing
$Regkeys = "HKLM\SYSTEM\CurrentControlSet\Control\ProductOptions" 
$OutputFile = $ComputerName + "_reg_ProductOptions_HKLM.txt"
RegQuery -RegistryKeys $Regkeys -Recursive $true -OutputFile $OutputFile -fileDescription "Product Options Registry Key" -SectionDescription "Software Registry keys"

$Regkeys = "HKLM\SYSTEM\CurrentControlSet\Control\FastCache" 
$OutputFile = $ComputerName + "_reg_FastCache_HKLM.txt"
RegQuery -RegistryKeys $Regkeys -Recursive $true -OutputFile $OutputFile -fileDescription "FastCache Registry Key" -SectionDescription "Software Registry keys"

# Windows RunTime Key
$Regkeys = "HKLM\Software\Microsoft\WindowsRuntime" 
$OutputFile = $ComputerName + "_reg_WindowsRuntime_HKLM.txt"
RegQuery -RegistryKeys $Regkeys -Recursive $true -OutputFile $OutputFile -fileDescription "WindowsRuntime Registry Key" -SectionDescription "Software Registry keys"
  

# Saved Directories
"Getting copies of System Files" | WriteTo-StdOut
Write-DiagProgress -Activity $ScriptStrings.ID_SystemFiles_Title -Status $ScriptStrings.ID_SystemFiles_Status
$sectionDescription = "System Files"
if(test-path "$env:WinDir\Panther")
{
	$DesinationTempFolder = Join-Path ($PWD.Path) ([System.Guid]::NewGuid().ToString())
	Copy-Item "$env:WinDir\Panther" -Destination $DesinationTempFolder -Force -Recurse -ErrorAction SilentlyContinue
	CompressCollectFiles -filesToCollect $DesinationTempFolder -DestinationFileName "Panther.zip" -fileDescription "Windows\Panther files" -sectionDescription $sectionDescription -Recursive
	Remove-Item $DesinationTempFolder -Force -Recurse
}

if(test-path "$env:SystemDrive\ProgramData\Microsoft\Windows\WER")
{
	$DesinationTempFolder = Join-Path ($PWD.Path) ([System.Guid]::NewGuid().ToString())
	Copy-Item "$env:SystemDrive\ProgramData\Microsoft\Windows\WER" -Destination $DesinationTempFolder -Force -Recurse -ErrorAction SilentlyContinue
	CompressCollectFiles -filesToCollect $DesinationTempFolder -DestinationFileName "WER.zip" -fileDescription "Windows Error Reporting files" -sectionDescription $sectionDescription -Recursive
	Remove-Item $DesinationTempFolder -Force -Recurse
}

if(test-path "$env:WinDir\WinStore")
{
	$DesinationTempFolder = Join-Path ($PWD.Path) ([System.Guid]::NewGuid().ToString())
	Copy-Item "$env:WinDir\WinStore" -Destination $DesinationTempFolder -Force -Recurse -ErrorAction SilentlyContinue
	CompressCollectFiles -filesToCollect $DesinationTempFolder -DestinationFileName "WinStore.zip" -fileDescription "Windows\WinStore files" -sectionDescription $sectionDescription -Recursive
	Remove-Item $DesinationTempFolder -Force -Recurse
}


# Directory Listings
"Getting Directory Listing of System Files" | WriteTo-StdOut
Write-DiagProgress -Activity $ScriptStrings.ID_SystemFilesDirectoryListings_Title -Status $ScriptStrings.ID_SystemFilesDirectoryListings_Status
$sectionDescription = "System Files Directory Listings"

if(test-path "$env:windir\System32")
{	$OutputFile= $Computername + "_DirList_System32.txt"
	dir "$env:windir\System32"                                  >> $OutputFile
	CollectFiles -filesToCollect $OutputFile -fileDescription "System32 Directory Listings" -sectionDescription $sectionDescription
}

if(test-path "$env:windir\SysWow64")
{	$OutputFile= $Computername + "_DirList_SystemWow64.txt"
	dir "$env:windir\SysWow64"                                  >> $OutputFile
	CollectFiles -filesToCollect $OutputFile -fileDescription "SysWow64 Directory Listings" -sectionDescription $sectionDescription
}
$OutputFile= $Computername + "_DirList_UsageLogs.txt"
dir "$env:LOCALAPPDATA\Packages\*\AC\Microsoft\CLR_v4.0_32\UsageLogs\*.log" >> $OutputFile
CollectFiles -filesToCollect $OutputFile -fileDescription "Usage Logs Directory Listings" -sectionDescription $sectionDescription

# Permission Data
"Getting ACL Listing of System Files" | WriteTo-StdOut
Write-DiagProgress -Activity $ScriptStrings.ID_SystemFilesACLListings_Title -Status $ScriptStrings.ID_SystemFilesACLListings_Status
$sectionDescription = "System Files ACL Listings"
$OutputFile= $Computername + "_ACLs_WinSxs.txt"
Get-Acl "$env:windir\winsxs"   | fl  > $OutputFile
CollectFiles -filesToCollect $OutputFile -fileDescription "WinSxs ACL Listings" -sectionDescription $sectionDescription
$OutputFile= $Computername + "_ACLs_system32.txt"
Get-Acl "$env:windir\System32" | fl  > $OutputFile
CollectFiles -filesToCollect $OutputFile -fileDescription "System32 ACL Listings" -sectionDescription $sectionDescription
$OutputFile= $Computername + "_ACLs_SystemApps.txt"
Get-Acl "$env:windir\SystemApps" | fl  > $OutputFile
CollectFiles -filesToCollect $OutputFile -fileDescription "SystemApps ACL Listings" -sectionDescription $sectionDescription
$OutputFile= $Computername + "_ACLs_WindowsApps.txt"
Get-Acl "$env:ProgramFiles\WindowsApps" | fl  > $OutputFile
CollectFiles -filesToCollect $OutputFile -fileDescription "WindowsApps ACL Listings" -sectionDescription $sectionDescription

# May need additional Work on these two.
$OutputFile= $Computername + "_ACLs.txt"
Get-ACL 'HKLM:\', 'HKCU:\', 'hklm:\software\microsoft\ole', 'hklm:\system\currentcontrolset'| fl > $OutputFile
CollectFiles -filesToCollect $OutputFile -fileDescription "ACLs" -sectionDescription $sectionDescription

"Getting DCOM Permissions" | WriteTo-StdOut
Write-DiagProgress -Activity $ScriptStrings.ID_DCOMPermissions_Title -Status $ScriptStrings.ID_DCOMPermissions_Status
$sectionDescription = "DCOM Permissions"
$OutputFile = $Computername + "_DCOMPerms.txt"
$Reg = [WMIClass]"\\.\root\default:StdRegProv"
 $DCOMMachineLaunchRestriction = $Reg.GetBinaryValue(2147483650,"software\microsoft\ole","MachineLaunchRestriction").uValue
 $DCOMMachineAccessRestriction = $Reg.GetBinaryValue(2147483650,"software\microsoft\ole","MachineAccessRestriction").uValue
 $DCOMDefaultLaunchPermission = $Reg.GetBinaryValue(2147483650,"software\microsoft\ole","DefaultLaunchPermission").uValue
 $DCOMDefaultAccessPermission = $Reg.GetBinaryValue(2147483650,"software\microsoft\ole","DefaultAccessPermission").uValue
 $converter = new-object system.management.ManagementClass Win32_SecurityDescriptorHelper
 $CurrentDCOMSDDLMachineLaunchRestriction = $converter.BinarySDToSDDL($DCOMMachineLaunchRestriction)
 $CurrentDCOMSDDLMachineAccessRestriction = $converter.BinarySDToSDDL($DCOMMachineAccessRestriction)
 $CurrentDCOMSDDLDefaultLaunchPermission = $converter.BinarySDToSDDL($DCOMDefaultLaunchPermission)
 $CurrentDCOMSDDLDefaultAccessPermission = $converter.BinarySDToSDDL($DCOMDefaultAccessPermission)

$CurrentDCOMSDDLMachineLaunchRestriction | fl | Out-File -FilePath $OutputFile -append
$CurrentDCOMSDDLMachineAccessRestriction | fl | Out-File -FilePath $OutputFile -append
$CurrentDCOMSDDLDefaultLaunchPermission  | fl | Out-File -FilePath $OutputFile -append
$CurrentDCOMSDDLDefaultAccessPermission  | fl | Out-File -FilePath $OutputFile -append
CollectFiles -filesToCollect $OutputFile -fileDescription "List of DCOM permissions" -sectionDescription $sectionDescription


# Event Logs
"Getting System Event Logs" | WriteTo-StdOut
$sectionDescription = "Event Logs"
$EventLogNames = "System", "Application"
Run-DiagExpression .\TS_GetEvents.ps1 -EventLogNames $EventLogNames -SectionDescription $sectionDescription

$EventLogNames = "Microsoft-Windows-BitLocker\BitLocker Management", "Microsoft-Windows-BitLocker-DrivePreparationTool\Admin", 
				 "Microsoft-Windows-BitLocker-DrivePreparationTool\Operational"
Run-DiagExpression .\TS_GetEvents.ps1 -EventLogNames $EventLogNames -SectionDescription $sectionDescription

$EventLogNames = "Microsoft-Windows-User Profile Service\Operational"
Run-DiagExpression .\TS_GetEvents.ps1 -EventLogNames $EventLogNames -SectionDescription $sectionDescription

$EventLogNames = "Microsoft-Windows-Bits-Client/Operational"
Run-DiagExpression .\TS_GetEvents.ps1 -EventLogNames $EventLogNames -SectionDescription $sectionDescription

$EventLogNames = "Microsoft-Windows-AppID/Operational"
Run-DiagExpression .\TS_GetEvents.ps1 -EventLogNames $EventLogNames -SectionDescription $sectionDescription



# Env Vars
"Getting Environment Variables" | WriteTo-StdOut
Write-DiagProgress -Activity $ScriptStrings.ID_EnvironmentVariables_Title -Status $ScriptStrings.ID_EnvironmentVariables_Status

$OutputFile = $ComputerName + "_EnvironmentVariables.txt"
get-childitem env: |out-file $OutputFile
$fileDescription = "Environment Variables"
$sectionDescription = "Environment Variables"
CollectFiles -filesToCollect $outfile -fileDescription $fileDescription -sectionDescription $sectionDescription

# ipconfig
"Getting IPConfig" | WriteTo-StdOut
Write-DiagProgress -Activity $ScriptStrings.ID_IPConfig_Title -Status $ScriptStrings.ID_IPConfig_Status
$OutputFile= $Computername + "_ipconfig.txt"
$CommandToExecute = "ipconfig /all > $OutputFile"
RunCmd -commandToRun $CommandToExecute -filesToCollect $OutputFile -fileDescription "IPConfig" -sectionDescription "IPConfig"

# System Policies
"Getting System Policies" | WriteTo-StdOut
Write-DiagProgress -Activity $ScriptStrings.ID_SystemPolicies_Title -Status $ScriptStrings.ID_SystemPolicies_Status
$OutputFile= $Computername + "_SystemPolicies.txt"
$CommandToExecute = "GpResult /R > $OutputFile"
RunCmd -commandToRun $CommandToExecute  -filesToCollect $OutputFile -fileDescription "Gpresult /r output" -sectionDescription "System Policies"

# Hosts file
"Getting Hosts File" | WriteTo-StdOut
$HostsFile  = "$ENV:windir\system32\drivers\etc\hosts"
if (test-path $HostsFile)
{	$OutputFile = $ComputerName + "_Dns_Hosts-file.txt"
	copy-item -Path $HostsFile -Destination $OutputFile -Force
  	CollectFiles -filesToCollect $HostsFile -fileDescription "Hosts File" -sectionDescription "Hosts"
}
else
{
  "$Hostsfile Does not exist" | writeto-stdout
}


# Proxy Settings
"Getting Proxy Settings" | WriteTo-StdOut
Write-DiagProgress -Activity $ScriptStrings.ID_ProxySettings_Title -Status $ScriptStrings.ID_ProxySettings_Status
$OutputFile= $Computername + "_netsh_proxy_settings.txt"
$CommandToExecute = "netsh winhttp show proxy >> $OutputFile"
RunCmd -commandToRun $CommandToExecute -filesToCollect $OutputFile -fileDescription "Proxy Settings" -sectionDescription "Proxy Settings"

# Get FireWall Service Status
"Getting FireWall Service Status" | WriteTo-StdOut
$MpsSvcStatus=(Get-Service -Name MpsSvc).Status
If ($MpsSvcStatus -eq "Running")
{
	"Status of FireWall Service is Running" | WriteTo-StdOut
}
else
{
	"Status of FireWall Service is NOT Running" | WriteTo-StdOut
}

# Root Certificates
Write-Host "$(Get-Date -UFormat "%R:%S") : Root Certificates"
"Getting Root Certificates" | WriteTo-StdOut
Write-DiagProgress -Activity $ScriptStrings.ID_RootCertificates_Title -Status $ScriptStrings.ID_RootCertificates_Status

$OutputFile = $ComputerName + "_RootCerts.txt"
get-childitem 'cert:\LocalMachine\root' |fl|Out-File $OutputFile
CollectFiles -filesToCollect $OutputFile -fileDescription "List of Root Certificates" -sectionDescription "Root Certs"

# Running Services
"Getting Running Services" | WriteTo-StdOut
Write-DiagProgress -Activity $ScriptStrings.ID_RunningServices_Title -Status $ScriptStrings.ID_RunningServices_Status
$OutputFile = $ComputerName + "_RunningServices.txt"
Get-Service | findstr /i 'running'|Out-File $Outputfile
CollectFiles -filesToCollect $OutputFile -sectionDescription "Running Services" -fileDescription "Running Services"

# Other logs
"Getting Logs" | WriteTo-StdOut
Write-DiagProgress -Activity $ScriptStrings.ID_OtherLogs_Title -Status $ScriptStrings.ID_OtherLogs_Status

$sectionDescription = "CBS + Setupapi Logs"
	$OutputFile = $ComputerName + "_CBS.log"
	copy-item -Path "$env:windir\Logs\CBS\CBS.log" -Destination $OutputFile -Force
	CollectFiles -filesToCollect $OutputFile  -fileDescription "CBS Log" -sectionDescription $sectionDescription
	$OutputFile = $ComputerName + "_setupapi.dev.log"
	copy-item -Path "$env:windir\inf\setupapi.dev.log" -Destination $OutputFile -Force
	CollectFiles -filesToCollect $OutputFile -fileDescription "Setupapi Log" -sectionDescription $sectionDescription

# Video Display Info
"Getting Video Display Logs" | WriteTo-StdOut
Write-DiagProgress -Activity $ScriptStrings.ID_OtherLogs_Title -Status "Video Display Info"
$OutputFile = $ComputerName + "_VideoDisplayInfo.txt"
Get-WmiObject win32_displaycontrollerconfiguration |Out-File $Outputfile
CollectFiles -sectionDescription "Display Info" -fileDescription "Display Info" -filesToCollect $OutputFile


# Network Adapter Info
"Getting Network Adapter Logs" | WriteTo-StdOut
Write-DiagProgress -Activity $ScriptStrings.ID_OtherLogs_Title -Status "Network Adapter Info"
$OutputFile = $ComputerName + "_NetworkAdapterInfo.txt"
Get-WmiObject Win32_NetworkAdapterConfiguration | out-file $Outputfile
CollectFiles -filesToCollect $Outputfile -fileDescription "Network Adapter Info" -sectionDescription "Network Adapter Info"

# OS Version Info
"Getting OS Version Info" | WriteTo-StdOut
Write-DiagProgress -Activity $ScriptStrings.ID_OtherLogs_Title -Status "OS Version Info"
$OutputFile = $ComputerName + "_WindowsVersionInfo.txt"
Get-WmiObject Win32_OperatingSystem |Out-File $Outputfile
CollectFiles -sectionDescription "OS Version Info" -fileDescription "OS Version Info" -filesToCollect $OutputFile


# Collect ETL Logs
Write-Host "$(Get-Date -UFormat "%R:%S") : Collect ETL Logs (tbd)"
"Getting ETL Logs" | WriteTo-StdOut
Write-DiagProgress -Activity $ScriptStrings.ID_ETLLogs_Title -Status $ScriptStrings.ID_ETLLogs_Status
if ($Global:runFull -eq $True) { # $False = disabling for now for this long-lasting step
	if(Test-Path "$env:localappdata\Packages\microsoft.windowscommunicationsapps_8wekyb3d8bbwe\LocalState")
	{
		$DesinationTempFolder = Join-Path ($PWD.Path) ([System.Guid]::NewGuid().ToString())
		Copy-Item "$env:localappdata\Packages\microsoft.windowscommunicationsapps_8wekyb3d8bbwe\LocalState" -Destination $DesinationTempFolder -Force -Recurse -ErrorAction SilentlyContinue
		CompressCollectFiles -filesToCollect $DesinationTempFolder -DestinationFileName "LiveComm.zip" -fileDescription "Windows Live applications ETL" -sectionDescription "ETL Logs" -Recursive
		Remove-Item $DesinationTempFolder -Force -Recurse
	}
}

Write-verbose "$(Get-Date -UFormat "%R:%S") :   end of script DC_SystemCollect.ps1"

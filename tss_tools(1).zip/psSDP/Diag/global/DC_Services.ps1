﻿#************************************************
# DC_Services.ps1
# Version 1.0
# Date: 2014, 2020
# Author: Boyd Benson (bbenson@microsoft.com) /WalterE
# Description: Collects information about running services
# Called from: Networking Diagnostics
#*******************************************************

Trap [Exception]
	{
	 # Handle exception and throw it to the stdout log file. Then continue with function and script.
		 $Script:ExceptionMessage = $_
		 "[info]: Exception occurred."  | WriteTo-StdOut
		 "[info]: Exception.Message $ExceptionMessage."  | WriteTo-StdOut 
		 $Error.Clear()
		 continue
		 # later use return to return the exception message to an object:   return $Script:ExceptionMessage
	}


Import-LocalizedData -BindingVariable ScriptVariable
 Write-DiagProgress -Activity $ScriptVariable.ID_CTSSMBClient -Status $ScriptVariable.ID_CTSSMBClientDescription

function RunSc ([string]$ScCommandToExecute="")
{
	$ScCommandToExecuteLength = $ScCommandToExecute.Length + 6
	"`n`n`n" + "=" * ($ScCommandToExecuteLength) + "`r`n" + "sc $ScCommandToExecute" + "`r`n" + "=" * ($ScCommandToExecuteLength) | Out-File -FilePath $OutputFile -append

	$CommandToExecute = "cmd.exe /c sc.exe " + $ScCommandToExecute + " >> $OutputFile "
	RunCmD -commandToRun $CommandToExecute  -CollectFiles $false
	"`n`n`n" | Out-File -FilePath $OutputFile -append
}


$sectionDescription = "Services"

$OutputFile= $Computername + "_Services_active_info.TXT"
"====================================================
Services Active SC Output
====================================================
Overview
----------------------------------------------------
   1. sc query
====================================================
`n`n`n"												| Out-File -FilePath $OutputFile -append
RunSc "query"
CollectFiles -filesToCollect $OutputFile -fileDescription "Services Information" -SectionDescription $sectionDescription

$OutputFile= $Computername + "_Services_info.TXT"
"====================================================
Services SC Output
====================================================
Overview
----------------------------------------------------
   1. sc query type= all state= all
====================================================
`n`n`n"												| Out-File -FilePath $OutputFile -append
RunSc "query type= all state= all"
CollectFiles -filesToCollect $OutputFile -fileDescription "Services Information" -SectionDescription $sectionDescription

﻿#************************************************
# Function.ps1
# Version 1.0.0
# Date: 03-01-2012
# Author: Wilson Souza - wsouza@microsoft.com
# Description: This script contains functions used by others ps1 files
#************************************************
Import-LocalizedData -BindingVariable ScriptStrings

function GetDPMInstallFolder
{
	if ((Test-Path "HKLM:SOFTWARE\Microsoft\Microsoft Data Protection Manager\Setup") -eq $true)
	{
		return (get-itemproperty HKLM:\SOFTWARE\Microsoft\"Microsoft Data Protection Manager"\Setup).InstallPath
	} Else {
		$null
	}
}

Function DPMVersion ([String]$Folder)
{
	$DPMFile = $Folder + "bin\msdpm.exe"
	if(Test-Path $DPMFile)
	{
		$MSDPM_Version = [System.Diagnostics.FileVersionInfo]::GetVersionInfo($dpmfile).filemajorpart
		Return $MSDPM_Version
	}
	else
	{
		$Folder + "bin\msdpm.exe is not found" | WriteTo-StdOut 
	}
}

Function DPMRAVersion ([String]$Folder)
{
	$DPMRAFile = $Folder + "bin\dpmra.exe"
	if(Test-Path $DPMRAFile)
	{
		$DPMRA_Version = [System.Diagnostics.FileVersionInfo]::GetVersionInfo($DPMRAFile).filemajorpart
		Return $DPMRA_Version
	}
	else
	{
		$Folder + "bin\dpmra.exe is not found" | WriteTo-StdOut 
	}
}


####################################################################################
# Check to be see if DPM is installed
####################################################################################
Function IsDPMInstalled
{
	$IsDPMInstalled = $false
	if (Test-Path "HKLM:SOFTWARE\Microsoft\Microsoft Data Protection Manager\Setup")	
	{
		$IsDPMInstalled =(get-itemproperty "HKLM:\SOFTWARE\Microsoft\Microsoft Data Protection Manager\Setup").InstallPath 
		if(!([string]::IsNullOrEmpty($IsDPMInstalled)))
		{
			$IsDPMInstalled = $true
		}
	}
	return $IsDPMInstalled
}

####################################################################################
# Check to be see if Microsoft Azure Backup is installed
####################################################################################
Function IsMABInstalled
{
	$IsMABInstalled = $false
	if (Test-Path "HKLM:SOFTWARE\Microsoft\Windows Azure Backup\Setup")	
	{
		$IsMABInstalled =(get-itemproperty "HKLM:\SOFTWARE\Microsoft\Windows Azure Backup\Setup").InstallPath 
		if(!([string]::IsNullOrEmpty($IsMABInstalled)))
		{
			$IsMABInstalled = $true
		}
	}
	return $IsMABInstalled
}

####################################################################################
# Check to be see if it is a DPM Server or a protected server
####################################################################################
Function IsDPMServer
{
	if (Test-Path "HKLM:SOFTWARE\Microsoft\Microsoft Data Protection Manager\DB")
	{
		return $true
	}
	else
	{
		return $false
	}	
}

####################################################################################
# Check to be sure the DPM namespace is loaded, if not then load it
####################################################################################
function LoadDPMNamespace ()
{	
	Write-DiagProgress -Activity $ScriptStrings.ID_DPM_Obtain_DPM_Information_Title -Status $ScriptStrings.ID_DPM_Obtain_DPM_Information_Status
	$DPMFolder = GetDPMInstallFolder	
	$DPMVersion = DPMVersion ($DPMFolder)
	Switch ($DPMVersion)
	{	
		2	{
				if (!(get-PSSnapin | ? { $_.name -eq 'Microsoft.DataProtectionManager.PowerShell'}))
				{
					Add-PSSnapin -name Microsoft.DataProtectionManager.PowerShell
				}
			}
		3	{
				if (!(get-PSSnapin | ? { $_.name -eq 'Microsoft.DataProtectionManager.PowerShell'}))
				{
					Add-PSSnapin -name Microsoft.DataProtectionManager.PowerShell
				}
			}
		4	{
				Import-Module -name dataprotectionmanager
			}
	}
} 

####################################################################################
# Format an XML string in indentation format for easier read
####################################################################################
function Format-XML ([xml]$xml, $indent=2) 
{ 
    $StringWriter = New-Object System.IO.StringWriter 
    $XmlWriter = New-Object System.XMl.XmlTextWriter $StringWriter 
    $xmlWriter.Formatting = "indented" 
    $xmlWriter.Indentation = $Indent 
    $xml.WriteContentTo($XmlWriter) 
    $XmlWriter.Flush() 
    $StringWriter.Flush() 
    Write-Output $StringWriter.ToString() 
}

# NEED TO change the entires below to look at the date and only collect logs where last write time is withing the 30 days or passed in time period

# CompressCollectFilesForTimePeriod function
# ---------------------
# Description:
#       This function compresses files in a ZIP or CAB file, collecting these files after the ZIP file is created
#       ZIP format is way faster than CAB but - once Shell is used for ZIP files, there is no support for ZIP files on ServerCore
#       Where support for ZIP files is inexistent (like on ServerCore), function will automatically switch to CAB
#
# Arguments:
#		filesToCollect: Folder or Files that to be collected (Ex: C:\windows\*.txt). This value can also be an array.
#       DestinationFileName: Destination name for the zip file (Ex: MyZipFile.ZIP or MyCabFile.CAB)
#		fileDescription: Individual description of the zip file 
#		sectionDescription: Section description.
#       Recursive: Copy files in subfolders
#       renameOutput: Add the %ComputerName% prefix to the ZIP file name - if not existent
#       noFileExtensionsOnDescription: Do not add file extension to the file description (Default format is $fileDescription ($FileExtension))
#       Verbosity: When $collectFiles is true, $Verbosity is the verbosity level for CollectFiles function
#       DoNotCollectFile: If present, function will generate the ZIP file but it will not collect it
#       ForegroundProcess: *Only for CAB files - By default CAB files are compressed in a Background process. Use -ForegroundProcess to force waiting for compression routine to complete before continuing.

function CompressCollectFilesForTimePeriod
{
	PARAM($filesToCollect,
		[string]$DestinationFileName="File.zip",
		[switch]$Recursive,
		[string]$fileDescription="File", 
		[string]$sectionDescription="Section",
		[boolean]$renameOutput=$true,
		[switch]$noFileExtensionsOnDescription,
		[string]$Verbosity="Informational",
		[switch]$DoNotCollectFile,
		[switch]$ForegroundProcess=$false,
		[int]$NumberOfDays="30" # Collect last 15 days of files if not present
		)

	$FileFormat = [System.IO.Path]::GetExtension($DestinationFileName)

	if ($FileFormat.Length -ne 4) {$FileFormat = ".zip"}

	if ((-not (Test-Path -Path (join-path ([Environment]::SystemDirectory) "shell32.dll"))) -and ($FileFormat -eq ".zip")) 
	{
		"[CompressCollectFilesForTimePeriod] - File format was switched to .CAB once shell is not present" | WriteTo-StdOut -ShortFormat
		$FileFormat = ".cab"
	}
	
	if (($renameOutput -eq $true) -and (-not $DestinationFileName.StartsWith($ComputerName))) 
	{
		$CompressedFileNameWithoutExtension = $ComputerName + "_" + [System.IO.Path]::GetFileNameWithoutExtension($DestinationFileName)
	} else {
		# if ($DestinationFileName.Contains("zip_dpmerrlog"))
		if ($DestinationFileName.Contains(".zip"))
		{
			$CompressedFileNameWithoutExtension = $DestinationFileName
		} else {
			$CompressedFileNameWithoutExtension = [System.IO.Path]::GetFileNameWithoutExtension($DestinationFileName)
		}
	}

	$CompressedFileName = ($PWD.Path) + "\" + $CompressedFileNameWithoutExtension + $FileFormat

	if ($FileFormat -eq ".cab")
	{
		#Create DDF File
		$ddfFilename = $ddfFilename = $env:temp + [System.IO.Path]::DirectorySeparatorChar + [System.IO.Path]::GetRandomFileName();
		
	    ".Set DiskDirectoryTemplate=" + "`"" + $PWD.Path + "`"" | Out-File -FilePath $ddfFilename -Encoding "UTF8";
	    ".Set CabinetNameTemplate=`"" + [IO.Path]::GetFileName($CompressedFileName) + "`""| Out-File -FilePath $ddfFilename -Encoding "UTF8" -Append;
	 
	    ".Set Cabinet=ON" | Out-File -FilePath $ddfFilename -Encoding "UTF8" -Append;
	    ".Set Compress=ON" | Out-File -FilePath $ddfFilename -Encoding "UTF8" -Append;
	    ".Set InfAttr=" | Out-File -FilePath $ddfFilename -Encoding "UTF8" -Append;
		".Set FolderSizeThreshold=2000000" | Out-File -FilePath $ddfFilename -Encoding "UTF8" -Append;
		".Set MaxCabinetSize=0" | Out-File -FilePath $ddfFilename -Encoding "UTF8" -Append;
		".Set MaxDiskSize=0" | Out-File -FilePath $ddfFilename -Encoding "UTF8" -Append;
	}

	$ShellGetAllItems = {
	PARAM ($ShellFolderObj, $ZipFileName)
		if ($ShellFolderObj -is "System.__ComObject")
		{
			$ArrayResults = @()
			foreach ($ZipFileItem in $ShellFolderObj.Items())
			{
				$ArrayResults += $ZipFileItem.Path.Substring($ZipFileName.Length + 1)
				
				if ($ZipFileItem.IsFolder)
				{
					$ArrayResults += $ShellGetAllItems.Invoke((new-object -com Shell.Application).NameSpace($ZipFileItem.Path), $ZipFileName)
				}
			}
			return $ArrayResults
		}
	}

	ForEach ($pathFilesToCollect in $filesToCollect) 
	{
		 #I think we're right here when we go through all of the loop of files
		"[CompressCollectFilesForTimePeriod] Compressing " + $pathFilesToCollect + " to " + [System.IO.Path]::GetFileName($CompressedFileName) | WriteTo-StdOut -ShortFormat
		
		if (test-path ([System.IO.Path]::GetDirectoryName($pathFilesToCollect)) -ErrorAction SilentlyContinue) 
		{
		
			if ($Recursive.IsPresent) 
			{
				$FileExtension = Split-Path $pathFilesToCollect -leaf
				$RootFolder = [System.IO.Path]::GetDirectoryName($pathFilesToCollect)
				if ($FileExtension -eq "*.*" -and $FileFormat -eq ".zip")
				{
					#Optimization to collect subfolders on ZIP files
					$FilestobeCollected = Get-ChildItem -Path ([System.IO.Path]::GetDirectoryName($pathFilesToCollect))
				} else {
					$FilestobeCollected = Get-ChildItem -Path ([System.IO.Path]::GetDirectoryName($pathFilesToCollect)) -Include $FileExtension -Recurse
				}
				$SubfolderToBeCollected = $FilestobeCollected | Select-Object -Unique -ExpandProperty "Directory"
			} else {
				$FilestobeCollected = Get-ChildItem -Path $pathFilesToCollect
			}
			if ((($FilestobeCollected -is [array]) -and ($FilestobeCollected.Count -gt 0)) -or ($FilestobeCollected -ne $null))
			{
		 		switch ($FileFormat)
				{
					".zip" 
					{
						#Create file if it does not exist, otherwise just add to the ZIP file name
						$FilesToSkip = @()
						if (-not (Test-Path($CompressedFileName))) 
						{
							Set-Content $CompressedFileName ("PK" + [char]5 + [char]6 + ("$([char]0)" * 18))
						} else {
							#Need to check file name conflicts, otherwise Shell will raise a message asking for overwrite
							$ZipFileObj = (new-object -com Shell.Application).NameSpace($CompressedFileName)
							$FilesToBeCollectedFullPath = ($FilestobeCollected | Select-Object -ExpandProperty "FullName")
							$AllZipItems = $ShellGetAllItems.Invoke($ZipFileObj, $CompressedFileName)
							
							foreach ($ZipFileItem in $AllZipItems)
							{
								$FileNameToCheck = $RootFolder + "\" + $ZipFileItem
								if ($FilesToBeCollectedFullPath -contains $FileNameToCheck)
								{
									if (($FileExtension -eq "*.*") -or ([System.IO.Directory]::Exists($FileNameToCheck) -eq $false)) #Check if it is a folder, so it will not fire a message on stdout.log
									{
										#Error - File Name Conflics exist
										$ErrorDisplay = "[CompressCollectFiles] Error: One or more file name conflicts when compressing files were detected:`r`n"
										$ErrorDisplay += "        File Name   : "+ $FileNameToCheck + "`r`n"
										$ErrorDisplay += "        Zip File    : " + $CompressedFileName + "`r`n"
										$ErrorDisplay += "   File/ Folder will not be compressed."
										$ErrorDisplay | WriteTo-StdOut
									}
									$FilesToSkip += $FileNameToCheck
								}
							}
						} #end else
						
						if($debug -eq $true){[void]$shell.popup("Processing list of files:t")}						
																	
						$currentDate = [System.DateTime]::Now

						#TODO: Add if NumOfDays > 0 then default to 0 for all files
						
						#Create emtpy array
						$NewFileList = @()
						
						foreach ($NameOfFile in $FilestobeCollected)
						{
							$LastTime = $NameOfFile.LastWriteTime
							$TimeDiff = ($currentDate - $LastTime).Days

							if ($TimeDiff -le $NumberOfDays)
							{
								#Now add to list
								$NewFileList += $NameOfFile
							}
							
						}
						$FilestobeCollected = $NewFileList
						
						$ExecutionTimeout = 20 #Time-out for compression - in minutes

						$ZipFileObj = (new-object -com Shell.Application).NameSpace($CompressedFileName)
						$InitialZipItemCount = 0
						
						if (($Recursive.IsPresent) -and ($FileExtension -ne "*.*"))
						{
							#Create Subfolder structure on ZIP files
							$TempFolder = mkdir -Path ($Env:TEMP + "\ZIP" + (Get-Random).toString())
							$TempFolderObj = (new-object -com Shell.Application).NameSpace($TempFolder.FullName)
							
							foreach ($SubfolderToCreateOnZip in $SubfolderToBeCollected | Select-Object -ExpandProperty "FullName")
							{
								$RelativeFolder = $SubfolderToCreateOnZip.Substring($RootFolder.Length)
								if ($RelativeFolder.Length -gt 0)
							{
									$TempFolderToCreate = (Join-Path $TempFolder $RelativeFolder)
									MKDir -Path $TempFolderToCreate | Out-Null
									"Temporary file" |Out-File -FilePath ($TempFolderToCreate + "\_DeleteMe.Txt") -Append #Temporary file just to make sure file isn't empty so it won't error out when using 'CopyHere
								}
							}
							#Create subfolder structure on ZIP file:
							
							foreach ($ParentTempSubfolder in $TempFolder.GetDirectories("*.*", [System.IO.SearchOption]::AllDirectories))
							{
								if (($AllZipItems -eq $null) -or ($AllZipItems -notcontains ($ParentTempSubfolder.FullName.Substring($TempFolder.FullName.Length+1))))
								{
									
									$TimeCompressionStarted = Get-Date
									$ZipFileObj = (new-object -com Shell.Application).NameSpace($CompressedFileName + $ParentTempSubfolder.Parent.FullName.Substring($TempFolder.FullName.Length))
								$InitialZipItemCount = $ZipFileObj.Items().Count
								$ZipFileObj.CopyHere($ParentTempSubfolder.FullName, $DontShowDialog)
									do
									{
										sleep -Milliseconds 100
										
										if ((New-TimeSpan -Start $TimeCompressionStarted).Minutes -ge 2)
										{
											$ErrorDisplay = "[CompressCollectFilesForTimePeriod] Compression routine will be terminated due it reached a timeout of 2 minutes to create a subfolder on zip file:`r`n"
											$ErrorDisplay += "        SubFolder   : " + $RootFolder + $ParentTempSubfolder.FullName.Substring($TempFolder.FullName.Length) + "`r`n"
											$ErrorDisplay += "        Start Time  : " + $TimeCompressionStarted + "`r`n"
											$ErrorDisplay | WriteTo-StdOut
											$TimeoutOcurred = $true
										}
																
									} while ((-not $TimeoutOcurred) -and ($ZipFileObj.Items().Count -le $InitialZipItemCount))
									
									$AllZipItems += [System.IO.Directory]::GetDirectories($ParentTempSubfolder.FullName, "*.*", [System.IO.SearchOption]::AllDirectories) | ForEach-Object -Process {$_.Substring($TempFolder.FullName.Length + 1)}
									$AllZipItems  = $ShellGetAllItems.Invoke($ZipFileObj, $CompressedFileName)
								}
							}
						}
						
						if (($ZipFileObj -eq $null) -or ($ZipFileObj.Self.Path -ne $CompressedFileName))
						{
							$ZipFileObj = (new-object -com Shell.Application).NameSpace($CompressedFileName)
						}
					} # switch .zip
				} #switch
		
			$FilestobeCollected | ForEach-object -process {
				
					$FileName = Split-Path $_.Name -leaf
					$FileNameFullPath = $_.FullName
					if (($Recursive.IsPresent) -and ([System.IO.Path]::GetDirectoryName($FileNameFullPath).Length -gt [System.IO.Path]::GetDirectoryName($pathFilesToCollect).Length))
					{
						$RelativeFolder = [System.IO.Path]::GetDirectoryName($FileNameFullPath).Substring([System.IO.Path]::GetDirectoryName($pathFilesToCollect).Length)
					} else {
						$RelativeFolder = ""
						$CurrentZipFolder = ""
					} 
					
			 		switch ($FileFormat)
					{
						".zip" 
						{
							$TimeCompressionStarted = Get-Date
							$TimeoutOcurred = $false

							if (($FileExtension -eq "*.*") -and ([System.IO.Directory]::Exists($FileNameFullPath)))
							{
								#Check if folder does not have any file
								if (([System.IO.Directory]::GetFiles($FileNameFullPath, "*.*", [System.IO.SearchOption]::AllDirectories)).Count -eq 0)
								{
									$FilesToSkip += $FileNameFullPath 
									"[CompressCollectFilesForTimePeriod] Folder $FileNameFullPath will not be compressed since it does not contain any file`r`n"
								}
							}

						if ($RelativeFolder -ne $CurrentZipFolder)
							{
								$ZipFileObj = (new-object -com Shell.Application).NameSpace((join-path $CompressedFileName $RelativeFolder))
								ForEach ($TempFile in $ZipFileObj.Items()) 
								{
									#Remove temporary file from ZIP
									if ($TempFile.Name -eq "_DeleteMe") 
									{
										$DeleteMeFileOnTemp = (Join-Path $TempFolder.FullName "_DeleteMe.TXT")
										if (Test-Path $DeleteMeFileOnTemp) {Remove-Item -Path $DeleteMeFileOnTemp}
										$TempFolderObj.MoveHere($TempFile)
										if (Test-Path $DeleteMeFileOnTemp) {Remove-Item -Path (Join-Path $TempFolder.FullName "_DeleteMe.TXT")}
									}
								}
								$CurrentZipFolder = $RelativeFolder
							} elseif (($RelativeFolder.Length -eq 0) -and ($ZipFileObj.Self.Path -ne $CompressedFileName))
							{
								$ZipFileObj = (new-object -com Shell.Application).NameSpace($CompressedFileName)
							}
			
							if (($FilesToSkip -eq $null) -or ($FilesToSkip -notcontains $FileNameFullPath))
							{
								"             Adding " + $FileNameFullPath + " to " + [System.IO.Path]::GetFileName($CompressedFileName) + $ZipFileObj.Self.Path.Substring($CompressedFileName.Length) | WriteTo-StdOut -ShortFormat
								$InitialZipItemCount = $ZipFileObj.Items().Count
								$ZipFileObj.CopyHere($FileNameFullPath, $DontShowDialog)
						
								while ((-not $TimeoutOcurred) -and ($ZipFileObj.Items().Count -le $InitialZipItemCount))
								{
									sleep -Milliseconds 200
									
									if ((New-TimeSpan -Start $TimeCompressionStarted).Minutes -ge $ExecutionTimeout)
									{
										$ErrorDisplay = "[CompressCollectFilesForTimePeriod] Compression routine will be terminated due it reached a timeout of $ExecutionTimeout minutes:`r`n"
										$ErrorDisplay += "        File Name   : $FileNameFullPath `r`n"
										$ErrorDisplay += "        Start Time  : " + $TimeCompressionStarted + "`r`n"
										$ErrorDisplay | WriteTo-StdOut
										$TimeoutOcurred = $true
									}
															
								} 
							}
						}
						".cab"
						{
							if ($RelativeFolder -ne $CurrentCabFolder)
							{
								$ListOfFilesonDDF += ".Set DestinationDir=`"" + $RelativeFolder + "`"`r`n"
								$CurrentCabFolder = $RelativeFolder
							}
							$ListOfFilesonDDF += "`"" + $FileNameFullPath + "`"`r`n" 
						}
					}
				}   
			} else {
				"[CompressCollectFilesForTimePeriod] No files found: $pathFilesToCollect" | WriteTo-StdOut -ShortFormat
			}
		} else {
			"[CompressCollectFilesForTimePeriod] Path not found: $pathFilesToCollect" | WriteTo-StdOut -ShortFormat
		}
		if (($TempFolder -ne $null) -and ($TempFolder.Exists)) {$TempFolder.Delete($true)}
} #ForEach 	
	if (($FileFormat -eq ".zip") -and (Test-Path $CompressedFileName) -and (-not $DoNotCollectFile.IsPresent))
	{
		# Now check to see if this is a DPM Errorlog zipped file. if so remove the .zip extension
		# NOTE: The statement below is case sesitive with files

		# if ([System.IO.Path]::GetFileNameWithoutExtension($CompressedFileName).Contains("DPM_Error_Logs"))
		if ([System.IO.Path]::GetFileNameWithoutExtension($CompressedFileName).Contains("DPM_Error_Logs"))
		{
			if ($debug -eq $true) {[void]$shell.popup("Inside of rename")}
			[System.IO.File]::Move($CompressedFileName, $DestinationFileName)
			$CompressedFilename = [System.IO.Path]::GetFileNameWithoutExtension($CompressedFileName)
		}		
        "[CompressCollectFilesForTimePeriod] Calling CollectFiles with following parameters: -fileToCollect " +  $CompressedFileName | WriteTo-StdOut -ShortFormat
        CollectFiles -filesToCollect $CompressedFileName -fileDescription $fileDescription -sectionDescription $sectionDescription 
	}
	
	if ($FileFormat -eq ".cab")
	{
		if ($FilestobeCollected -ne $null) 
		{
			$ListOfFilesonDDF | Out-File -FilePath $ddfFilename -Encoding "UTF8" -Append;
			if ($ForegroundProcess.IsPresent)
			{
				Runcmd -commandToRun ($env:windir + "\system32\cmd.exe /c " +$env:windir + "\system32\makecab.exe /f `"" + $ddfFilename + "`" >nul") -fileDescription $fileDescription -sectionDescription $sectionDescription -filesToCollect $CompressedFileName -noFileExtensionsOnDescription ($noFileExtensionsOnDescription.IsPresent -eq $true) -Verbosity $Verbosity
				Remove-Item $ddfFilename
			} else {
				if ($noFileExtensionsOnDescription.IsPresent -eq $true)
				{
					BackgroundProcessCreate -ProcessName ($env:windir + "\system32\cmd.exe") -Arguments ("/c "+ $env:windir + "\system32\makecab.exe /f `"" + $ddfFilename + "`" >nul & del `"$ddfFilename`"") -fileDescription $fileDescription -sectionDescription $sectionDescription -filesToCollect $CompressedFileName -Verbosity $Verbosity -noFileExtensionsOnDescription
				} else {
					BackgroundProcessCreate -ProcessName ($env:windir + "\system32\cmd.exe") -Arguments ("/c "+ $env:windir + "\system32\makecab.exe /f `"" + $ddfFilename + "`" >nul & del `"$ddfFilename`"") -fileDescription $fileDescription -sectionDescription $sectionDescription -filesToCollect $CompressedFileName -Verbosity $Verbosity -noFileExtensionsOnDescription
				}
			}
		} else {
			Remove-Item $ddfFilename
		}
	} 
}


# SIG # Begin signature block
# MIIa3AYJKoZIhvcNAQcCoIIazTCCGskCAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQUnxcvtDsoAkv/ZIM4SAqYMeO4
# vIqgghWDMIIEwzCCA6ugAwIBAgITMwAAAJvgdDfLPU2NLgAAAAAAmzANBgkqhkiG
# 9w0BAQUFADB3MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4G
# A1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSEw
# HwYDVQQDExhNaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EwHhcNMTYwMzMwMTkyMTI5
# WhcNMTcwNjMwMTkyMTI5WjCBszELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hp
# bmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jw
# b3JhdGlvbjENMAsGA1UECxMETU9QUjEnMCUGA1UECxMebkNpcGhlciBEU0UgRVNO
# OjcyOEQtQzQ1Ri1GOUVCMSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBT
# ZXJ2aWNlMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAjaPiz4GL18u/
# A6Jg9jtt4tQYsDcF1Y02nA5zzk1/ohCyfEN7LBhXvKynpoZ9eaG13jJm+Y78IM2r
# c3fPd51vYJxrePPFram9W0wrVapSgEFDQWaZpfAwaIa6DyFyH8N1P5J2wQDXmSyo
# WT/BYpFtCfbO0yK6LQCfZstT0cpWOlhMIbKFo5hljMeJSkVYe6tTQJ+MarIFxf4e
# 4v8Koaii28shjXyVMN4xF4oN6V/MQnDKpBUUboQPwsL9bAJMk7FMts627OK1zZoa
# EPVI5VcQd+qB3V+EQjJwRMnKvLD790g52GB1Sa2zv2h0LpQOHL7BcHJ0EA7M22tQ
# HzHqNPpsPQIDAQABo4IBCTCCAQUwHQYDVR0OBBYEFJaVsZ4TU7pYIUY04nzHOUps
# IPB3MB8GA1UdIwQYMBaAFCM0+NlSRnAK7UD7dvuzK7DDNbMPMFQGA1UdHwRNMEsw
# SaBHoEWGQ2h0dHA6Ly9jcmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3Byb2R1Y3Rz
# L01pY3Jvc29mdFRpbWVTdGFtcFBDQS5jcmwwWAYIKwYBBQUHAQEETDBKMEgGCCsG
# AQUFBzAChjxodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY3Jv
# c29mdFRpbWVTdGFtcFBDQS5jcnQwEwYDVR0lBAwwCgYIKwYBBQUHAwgwDQYJKoZI
# hvcNAQEFBQADggEBACEds1PpO0aBofoqE+NaICS6dqU7tnfIkXIE1ur+0psiL5MI
# orBu7wKluVZe/WX2jRJ96ifeP6C4LjMy15ZaP8N0OckPqba62v4QaM+I/Y8g3rKx
# 1l0okye3wgekRyVlu1LVcU0paegLUMeMlZagXqw3OQLVXvNUKHlx2xfDQ/zNaiv5
# DzlARHwsaMjSgeiZIqsgVubk7ySGm2ZWTjvi7rhk9+WfynUK7nyWn1nhrKC31mm9
# QibS9aWHUgHsKX77BbTm2Jd8E4BxNV+TJufkX3SVcXwDjbUfdfWitmE97sRsiV5k
# BH8pS2zUSOpKSkzngm61Or9XJhHIeIDVgM0Ou2QwggTtMIID1aADAgECAhMzAAAB
# QJap7nBW/swHAAEAAAFAMA0GCSqGSIb3DQEBBQUAMHkxCzAJBgNVBAYTAlVTMRMw
# EQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVN
# aWNyb3NvZnQgQ29ycG9yYXRpb24xIzAhBgNVBAMTGk1pY3Jvc29mdCBDb2RlIFNp
# Z25pbmcgUENBMB4XDTE2MDgxODIwMTcxN1oXDTE3MTEwMjIwMTcxN1owgYMxCzAJ
# BgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25k
# MR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xDTALBgNVBAsTBE1PUFIx
# HjAcBgNVBAMTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjCCASIwDQYJKoZIhvcNAQEB
# BQADggEPADCCAQoCggEBANtLi+kDal/IG10KBTnk1Q6S0MThi+ikDQUZWMA81ynd
# ibdobkuffryavVSGOanxODUW5h2s+65r3Akw77ge32z4SppVl0jII4mzWSc0vZUx
# R5wPzkA1Mjf+6fNPpBqks3m8gJs/JJjE0W/Vf+dDjeTc8tLmrmbtBDohlKZX3APb
# LMYb/ys5qF2/Vf7dSd9UBZSrM9+kfTGmTb1WzxYxaD+Eaxxt8+7VMIruZRuetwgc
# KX6TvfJ9QnY4ItR7fPS4uXGew5T0goY1gqZ0vQIz+lSGhaMlvqqJXuI5XyZBmBre
# ueZGhXi7UTICR+zk+R+9BFF15hKbduuFlxQiCqET92ECAwEAAaOCAWEwggFdMBMG
# A1UdJQQMMAoGCCsGAQUFBwMDMB0GA1UdDgQWBBSc5ehtgleuNyTe6l6pxF+QHc7Z
# ezBSBgNVHREESzBJpEcwRTENMAsGA1UECxMETU9QUjE0MDIGA1UEBRMrMjI5ODAz
# K2Y3ODViMWMwLTVkOWYtNDMxNi04ZDZhLTc0YWU2NDJkZGUxYzAfBgNVHSMEGDAW
# gBTLEejK0rQWWAHJNy4zFha5TJoKHzBWBgNVHR8ETzBNMEugSaBHhkVodHRwOi8v
# Y3JsLm1pY3Jvc29mdC5jb20vcGtpL2NybC9wcm9kdWN0cy9NaWNDb2RTaWdQQ0Ff
# MDgtMzEtMjAxMC5jcmwwWgYIKwYBBQUHAQEETjBMMEoGCCsGAQUFBzAChj5odHRw
# Oi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY0NvZFNpZ1BDQV8wOC0z
# MS0yMDEwLmNydDANBgkqhkiG9w0BAQUFAAOCAQEAa+RW49cTHSBA+W3p3k7bXR7G
# bCaj9+UJgAz/V+G01Nn5XEjhBn/CpFS4lnr1jcmDEwxxv/j8uy7MFXPzAGtOJar0
# xApylFKfd00pkygIMRbZ3250q8ToThWxmQVEThpJSSysee6/hU+EbkfvvtjSi0lp
# DimD9aW9oxshraKlPpAgnPWfEj16WXVk79qjhYQyEgICamR3AaY5mLPuoihJbKwk
# Mig+qItmLPsC2IMvI5KR91dl/6TV6VEIlPbW/cDVwCBF/UNJT3nuZBl/YE7ixMpT
# Th/7WpENW80kg3xz6MlCdxJfMSbJsM5TimFU98KNcpnxxbYdfqqQhAQ6l3mtYDCC
# BbwwggOkoAMCAQICCmEzJhoAAAAAADEwDQYJKoZIhvcNAQEFBQAwXzETMBEGCgmS
# JomT8ixkARkWA2NvbTEZMBcGCgmSJomT8ixkARkWCW1pY3Jvc29mdDEtMCsGA1UE
# AxMkTWljcm9zb2Z0IFJvb3QgQ2VydGlmaWNhdGUgQXV0aG9yaXR5MB4XDTEwMDgz
# MTIyMTkzMloXDTIwMDgzMTIyMjkzMloweTELMAkGA1UEBhMCVVMxEzARBgNVBAgT
# Cldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29m
# dCBDb3Jwb3JhdGlvbjEjMCEGA1UEAxMaTWljcm9zb2Z0IENvZGUgU2lnbmluZyBQ
# Q0EwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQCycllcGTBkvx2aYCAg
# Qpl2U2w+G9ZvzMvx6mv+lxYQ4N86dIMaty+gMuz/3sJCTiPVcgDbNVcKicquIEn0
# 8GisTUuNpb15S3GbRwfa/SXfnXWIz6pzRH/XgdvzvfI2pMlcRdyvrT3gKGiXGqel
# cnNW8ReU5P01lHKg1nZfHndFg4U4FtBzWwW6Z1KNpbJpL9oZC/6SdCnidi9U3RQw
# WfjSjWL9y8lfRjFQuScT5EAwz3IpECgixzdOPaAyPZDNoTgGhVxOVoIoKgUyt0vX
# T2Pn0i1i8UU956wIAPZGoZ7RW4wmU+h6qkryRs83PDietHdcpReejcsRj1Y8wawJ
# XwPTAgMBAAGjggFeMIIBWjAPBgNVHRMBAf8EBTADAQH/MB0GA1UdDgQWBBTLEejK
# 0rQWWAHJNy4zFha5TJoKHzALBgNVHQ8EBAMCAYYwEgYJKwYBBAGCNxUBBAUCAwEA
# ATAjBgkrBgEEAYI3FQIEFgQU/dExTtMmipXhmGA7qDFvpjy82C0wGQYJKwYBBAGC
# NxQCBAweCgBTAHUAYgBDAEEwHwYDVR0jBBgwFoAUDqyCYEBWJ5flJRP8KuEKU5VZ
# 5KQwUAYDVR0fBEkwRzBFoEOgQYY/aHR0cDovL2NybC5taWNyb3NvZnQuY29tL3Br
# aS9jcmwvcHJvZHVjdHMvbWljcm9zb2Z0cm9vdGNlcnQuY3JsMFQGCCsGAQUFBwEB
# BEgwRjBEBggrBgEFBQcwAoY4aHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraS9j
# ZXJ0cy9NaWNyb3NvZnRSb290Q2VydC5jcnQwDQYJKoZIhvcNAQEFBQADggIBAFk5
# Pn8mRq/rb0CxMrVq6w4vbqhJ9+tfde1MOy3XQ60L/svpLTGjI8x8UJiAIV2sPS9M
# uqKoVpzjcLu4tPh5tUly9z7qQX/K4QwXaculnCAt+gtQxFbNLeNK0rxw56gNogOl
# VuC4iktX8pVCnPHz7+7jhh80PLhWmvBTI4UqpIIck+KUBx3y4k74jKHK6BOlkU7I
# G9KPcpUqcW2bGvgc8FPWZ8wi/1wdzaKMvSeyeWNWRKJRzfnpo1hW3ZsCRUQvX/Ta
# rtSCMm78pJUT5Otp56miLL7IKxAOZY6Z2/Wi+hImCWU4lPF6H0q70eFW6NB4lhhc
# yTUWX92THUmOLb6tNEQc7hAVGgBd3TVbIc6YxwnuhQ6MT20OE049fClInHLR82zK
# wexwo1eSV32UjaAbSANa98+jZwp0pTbtLS8XyOZyNxL0b7E8Z4L5UrKNMxZlHg6K
# 3RDeZPRvzkbU0xfpecQEtNP7LN8fip6sCvsTJ0Ct5PnhqX9GuwdgR2VgQE6wQuxO
# 7bN2edgKNAltHIAxH+IOVN3lofvlRxCtZJj/UBYufL8FIXrilUEnacOTj5XJjdib
# Ia4NXJzwoq6GaIMMai27dmsAHZat8hZ79haDJLmIz2qoRzEvmtzjcT3XAH5iR9HO
# iMm4GPoOco3Boz2vAkBq/2mbluIQqBC0N1AI1sM9MIIGBzCCA++gAwIBAgIKYRZo
# NAAAAAAAHDANBgkqhkiG9w0BAQUFADBfMRMwEQYKCZImiZPyLGQBGRYDY29tMRkw
# FwYKCZImiZPyLGQBGRYJbWljcm9zb2Z0MS0wKwYDVQQDEyRNaWNyb3NvZnQgUm9v
# dCBDZXJ0aWZpY2F0ZSBBdXRob3JpdHkwHhcNMDcwNDAzMTI1MzA5WhcNMjEwNDAz
# MTMwMzA5WjB3MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4G
# A1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSEw
# HwYDVQQDExhNaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EwggEiMA0GCSqGSIb3DQEB
# AQUAA4IBDwAwggEKAoIBAQCfoWyx39tIkip8ay4Z4b3i48WZUSNQrc7dGE4kD+7R
# p9FMrXQwIBHrB9VUlRVJlBtCkq6YXDAm2gBr6Hu97IkHD/cOBJjwicwfyzMkh53y
# 9GccLPx754gd6udOo6HBI1PKjfpFzwnQXq/QsEIEovmmbJNn1yjcRlOwhtDlKEYu
# J6yGT1VSDOQDLPtqkJAwbofzWTCd+n7Wl7PoIZd++NIT8wi3U21StEWQn0gASkdm
# EScpZqiX5NMGgUqi+YSnEUcUCYKfhO1VeP4Bmh1QCIUAEDBG7bfeI0a7xC1Un68e
# eEExd8yb3zuDk6FhArUdDbH895uyAc4iS1T/+QXDwiALAgMBAAGjggGrMIIBpzAP
# BgNVHRMBAf8EBTADAQH/MB0GA1UdDgQWBBQjNPjZUkZwCu1A+3b7syuwwzWzDzAL
# BgNVHQ8EBAMCAYYwEAYJKwYBBAGCNxUBBAMCAQAwgZgGA1UdIwSBkDCBjYAUDqyC
# YEBWJ5flJRP8KuEKU5VZ5KShY6RhMF8xEzARBgoJkiaJk/IsZAEZFgNjb20xGTAX
# BgoJkiaJk/IsZAEZFgltaWNyb3NvZnQxLTArBgNVBAMTJE1pY3Jvc29mdCBSb290
# IENlcnRpZmljYXRlIEF1dGhvcml0eYIQea0WoUqgpa1Mc1j0BxMuZTBQBgNVHR8E
# STBHMEWgQ6BBhj9odHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtpL2NybC9wcm9k
# dWN0cy9taWNyb3NvZnRyb290Y2VydC5jcmwwVAYIKwYBBQUHAQEESDBGMEQGCCsG
# AQUFBzAChjhodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY3Jv
# c29mdFJvb3RDZXJ0LmNydDATBgNVHSUEDDAKBggrBgEFBQcDCDANBgkqhkiG9w0B
# AQUFAAOCAgEAEJeKw1wDRDbd6bStd9vOeVFNAbEudHFbbQwTq86+e4+4LtQSooxt
# YrhXAstOIBNQmd16QOJXu69YmhzhHQGGrLt48ovQ7DsB7uK+jwoFyI1I4vBTFd1P
# q5Lk541q1YDB5pTyBi+FA+mRKiQicPv2/OR4mS4N9wficLwYTp2OawpylbihOZxn
# LcVRDupiXD8WmIsgP+IHGjL5zDFKdjE9K3ILyOpwPf+FChPfwgphjvDXuBfrTot/
# xTUrXqO/67x9C0J71FNyIe4wyrt4ZVxbARcKFA7S2hSY9Ty5ZlizLS/n+YWGzFFW
# 6J1wlGysOUzU9nm/qhh6YinvopspNAZ3GmLJPR5tH4LwC8csu89Ds+X57H2146So
# dDW4TsVxIxImdgs8UoxxWkZDFLyzs7BNZ8ifQv+AeSGAnhUwZuhCEl4ayJ4iIdBD
# 6Svpu/RIzCzU2DKATCYqSCRfWupW76bemZ3KOm+9gSd0BhHudiG/m4LBJ1S2sWo9
# iaF2YbRuoROmv6pH8BJv/YoybLL+31HIjCPJZr2dHYcSZAI9La9Zj7jkIeW1sMpj
# tHhUBdRBLlCslLCleKuzoJZ1GtmShxN1Ii8yqAhuoFuMJb+g74TKIdbrHk/Jmu5J
# 4PcBZW+JC33Iacjmbuqnl84xKf8OxVtc2E0bodj6L54/LlUWa8kTo/0xggTDMIIE
# vwIBATCBkDB5MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4G
# A1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSMw
# IQYDVQQDExpNaWNyb3NvZnQgQ29kZSBTaWduaW5nIFBDQQITMwAAAUCWqe5wVv7M
# BwABAAABQDAJBgUrDgMCGgUAoIHcMBkGCSqGSIb3DQEJAzEMBgorBgEEAYI3AgEE
# MBwGCisGAQQBgjcCAQsxDjAMBgorBgEEAYI3AgEVMCMGCSqGSIb3DQEJBDEWBBTQ
# f1yHQQCopPEvLIjlVQqCxMg8PDB8BgorBgEEAYI3AgEMMW4wbKBSgFAAUwB5AHMA
# dABlAG0AQwBlAG4AdABlAHIARABQAE0AXwBNAEEAQgBfAGcAbABvAGIAYQBsAF8A
# RgB1AG4AYwB0AGkAbwBuAHMALgBwAHMAMaEWgBRodHRwOi8vbWljcm9zb2Z0LmNv
# bTANBgkqhkiG9w0BAQEFAASCAQCK8GOjWgmyIFmDyZ92a79Feei+AgSbrLZQeOlr
# owvv3iobQMajPsV8szKhsYVBwbFca5wD5MXpBEzxVJhWW++gz2e2gYuQwWKERpsx
# 7i4Bn5h2HpLOjEj1BYXittWRdYLEHzadtPHDZr7EQQ7Gcj3KKqggx/zO328IadnR
# 1gdtwEfc6Tazfy/SClWAbASJ7ISLYn5UPibOwzgkogcvFGxYSrv7C9QU9pLFg4fi
# Yw5LPHhKPq0+mqqjxML9PJilXO+0gP6c52/soXRpQAhP9d6pYptC1auCGYR8TU37
# /InkVxKjJ3TNDxTuAKZEwJYdUAqWjX0uA2PXW0ir2JBt5OLYoYICKDCCAiQGCSqG
# SIb3DQEJBjGCAhUwggIRAgEBMIGOMHcxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpX
# YXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQg
# Q29ycG9yYXRpb24xITAfBgNVBAMTGE1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQQIT
# MwAAAJvgdDfLPU2NLgAAAAAAmzAJBgUrDgMCGgUAoF0wGAYJKoZIhvcNAQkDMQsG
# CSqGSIb3DQEHATAcBgkqhkiG9w0BCQUxDxcNMTYwODMwMjEzMTUwWjAjBgkqhkiG
# 9w0BCQQxFgQUkvfDrXHNOZPL8bSJNzj3MrfS2NYwDQYJKoZIhvcNAQEFBQAEggEA
# Ia/KmpXgL5KUoncseieHbX9HINNc+uQXSZcj0gamZZzw3yoScXIk5LIaVoXhVRki
# o3iByfPp7hnTygJDnKvARQcHnp2KI8tIIDa3jS7wVdOH/86g0xXJ4nEdxO0SSXFU
# 9ddBvJf2x6kBhsibS7spSZp+48SlkLBCNoEz4LicvREUScE1jNVJ5yLctb4TSylJ
# +BYFUK7W0uQYWCgdLFvWvQexfx9FOjrx4LeE6MK7ZzF52lOiXpF7jLCaDoB8DBnY
# WimY4rwr2KxKqUhHs+2Ad97DGYjwncUBJTDAn2QjVTiKrPU2C12xpdqm6GOHjalT
# JIop3RChZ5XWra6Z0xPgew==
# SIG # End signature block

﻿#************************************************
# DC_NAPClient-Component.ps1
# Version 1.0
# Date: 2009
# Author: Boyd Benson (bbenson@microsoft.com)
# Description: Collects information about the NAP Client.
# Called from: Main Networking Diag
#*******************************************************

Trap [Exception]
	{
	 # Handle exception and throw it to the stdout log file. Then continue with function and script.
		 $Script:ExceptionMessage = $_
		 "[info]: Exception occurred."  | WriteTo-StdOut
		 "[info]: Exception.Message $ExceptionMessage."  | WriteTo-StdOut 
		 $Error.Clear()
		 continue
		 # later use return to return the exception message to an object:   return $Script:ExceptionMessage
	}


Import-LocalizedData -BindingVariable ScriptVariable
Write-DiagProgress -Activity $ScriptVariable.ID_CTSNAPClient -Status $ScriptVariable.ID_CTSNAPClientDescription

# detect OS version and SKU
$wmiOSVersion = gwmi -Namespace "root\cimv2" -Class Win32_OperatingSystem
[int]$bn = [int]$wmiOSVersion.BuildNumber


function RunNetSH ([string]$NetSHCommandToExecute="")
{
	
	Write-DiagProgress -Activity $ScriptVariable.ID_CTSNAPClient -Status "netsh $NetSHCommandToExecute"
	
	$NetSHCommandToExecuteLength = $NetSHCommandToExecute.Length + 6
	"`n`n`n" + "-" * ($NetSHCommandToExecuteLength) + "`r`n" + "netsh $NetSHCommandToExecute" + "`r`n" + "-" * ($NetSHCommandToExecuteLength) | Out-File -FilePath $OutputFile -append

	$CommandToExecute = "cmd.exe /c netsh.exe " + $NetSHCommandToExecute + " >> $OutputFile "
	RunCmD -commandToRun $CommandToExecute  -CollectFiles $false
	"`n"	| Out-File -FilePath $OutputFile -append
	"`n"	| Out-File -FilePath $OutputFile -append
	"`n"	| Out-File -FilePath $OutputFile -append
}

$sectionDescription = "NAP Client"

#----------Netsh
$OutputFile = $ComputerName + "_NapClient_netsh_output.TXT"
"===================================================="	| Out-File -FilePath $OutputFile -append
"NAP Client Netsh Output"								| Out-File -FilePath $OutputFile -append
"===================================================="	| Out-File -FilePath $OutputFile -append
"Overview"												| Out-File -FilePath $OutputFile -append
"----------------------------------------------------"	| Out-File -FilePath $OutputFile -append
"   1. netsh nap client show config"					| Out-File -FilePath $OutputFile -append
"   2. netsh nap client show csps"						| Out-File -FilePath $OutputFile -append
"   3. netsh nap client show grouppolicy"				| Out-File -FilePath $OutputFile -append
"   4. netsh nap client show hashes"					| Out-File -FilePath $OutputFile -append
"   5. netsh nap client show state"						| Out-File -FilePath $OutputFile -append
"   6. netsh nap client show trustedservergroup"		| Out-File -FilePath $OutputFile -append
"===================================================="	| Out-File -FilePath $OutputFile -append
"`n"													| Out-File -FilePath $OutputFile -append
"`n"													| Out-File -FilePath $OutputFile -append
"`n"													| Out-File -FilePath $OutputFile -append
"`n"													| Out-File -FilePath $OutputFile -append
"`n"													| Out-File -FilePath $OutputFile -append
RunNetSH -NetSHCommandToExecute "nap client show config"
RunNetSH -NetSHCommandToExecute "nap client show csps"
RunNetSH -NetSHCommandToExecute "nap client show grouppolicy"
RunNetSH -NetSHCommandToExecute "nap client show hashes"
RunNetSH -NetSHCommandToExecute "nap client show state"
RunNetSH -NetSHCommandToExecute "nap client show trustedservergroup"

CollectFiles -filesToCollect $OutputFile -fileDescription "NAP Client netsh output" -SectionDescription $sectionDescription


#----------Registry
$OutputFile= $Computername + "_NapClient_reg_.TXT"
$CurrentVersionKeys =	"HKLM\SOFTWARE\Policies\Microsoft\NetworkAccessProtection",
						"HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows NT\Security Center",
						"HKLM\System\CurrentControlSet\Services\napagent"
RegQuery -Registrykeys $CurrentVersionKeys -Recursive $true -OutputFile $OutputFile -fileDescription "NAP Client Registry Keys" -SectionDescription $sectionDescription


#WV/WS2008+
if ($bn -gt 6000)
{
	#----------NetworkAccessProtection EventLogs
	$sectionDescription = "NAP Client EventLogs"
	$EventLogNames = "Microsoft-Windows-NetworkAccessProtection/Operational"
	$Prefix = ""
	$Suffix = "_evt_"
	.\TS_GetEvents.ps1 -EventLogNames $EventLogNames -SectionDescription $sectionDescription -Prefix $Prefix -Suffix $Suffix

	$EventLogNames = "Microsoft-Windows-NetworkAccessProtection/WHC"
	$Prefix = ""
	$Suffix = "_evt_"
	.\TS_GetEvents.ps1 -EventLogNames $EventLogNames -SectionDescription $sectionDescription -Prefix $Prefix -Suffix $Suffix
}

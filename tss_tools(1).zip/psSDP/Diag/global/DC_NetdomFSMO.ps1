﻿#*************************************************************
# Name:			DC_NetdomFSMO.ps1
# Version:		1.0.0
# Date:			2/5/12
# Author:		David Fisher (CSS)
# Description:	Determines the local Domain's FSMO role owners
#*************************************************************

# detect OS version and SKU #_#
$wmiOSVersion = gwmi -Namespace "root\cimv2" -Class Win32_OperatingSystem
[int]$bn = [int]$wmiOSVersion.BuildNumber

if($debug -eq $true){[void]$shell.popup("Run DC_NetdomFSMO.ps1")}
if (($OSArchitecture -eq 'ARM') -or ($bn -ge 9200)) #_# netdom.exe not running on W8+
{
	'Skipping running {netdom.exe} since it is not supported in ' + $OSArchitecture + ' architecture.' | WriteTo-StdOut
	return
}
Import-LocalizedData -BindingVariable NetdomStrings -FileName DC_NetdomFSMO -UICulture en-us
	
Write-DiagProgress -Activity $NetdomStrings.ID_NetdomFSMO -Status $NetdomStrings.ID_NetdomFSMODesc

$SectionDescription = "FSMO role owners"
$FileDescription = "Netdom Query FSMO Output"

$OutputFile = join-path $pwd.path ($ComputerName + "_NetdomFSMO.txt")
$CommandLineToExecute = $Env:windir + "\system32\cmd.exe /c netdom query fsmo > `"$OutputFile`""


RunCmD -commandToRun $CommandLineToExecute -sectionDescription $SectionDescription -filesToCollect $OutputFile -fileDescription $FileDescription

Trap{WriteTo-StdOut "$($_.InvocationInfo.ScriptName)($($_.InvocationInfo.ScriptLineNumber)): $_" -shortformat;Continue}

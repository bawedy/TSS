﻿
#************************************************
# DC_W32Time.ps1
# Version 1.0
# Date: 12-22-2010
# Author: clandis
# Description: Collects W32Time information
#************************************************

Import-LocalizedData -BindingVariable W32TimeStrings -FileName DC_W32Time -UICulture en-us

Write-DiagProgress -Activity $W32TimeStrings.ID_W32TimeOutput -Status $W32TimeStrings.ID_W32TimeObtaining

# If you specify a file name but not a full path for FileLogName, W32Time will try to write to %windir%\system32 but will fail with Access is Denied.
# So there is no point in checking for a file name but no full path, since it wouldn't allow debugging to actually be enabled anyway since the file wouldn't get written.

# Read the FileLogName value into the $FileLogName variable

$FileLogName = (get-itemproperty HKLM:\SYSTEM\CurrentControlSet\services\W32Time\Config\).FileLogName

# If $FileLogName is null (because FileLogName is not set) then throw an error.
If ($FileLogName -eq $null)	{
	"FileLogName registry value is not set. W32Time debug logging is not enabled." | Out-Host 
	} 
# If $FileLogName is populated, check if the path exists and if so, copy the file to current directory, prepending the computer name.
Else {
	"FileLogName = $FileLogName" | Out-Host 
	If (Test-Path $FileLogName) {
		"Copying $FileLogName to .\" + ($ComputerName + "_W32Time.log") | Out-Host
		Copy-Item $FileLogName (".\" + $ComputerName + "_W32Time.log")
		If (Test-Path (".\" + $ComputerName + "_W32Time.log")) {
			"File copy succeeded." | Out-Host 
			}
		Else {
			"File copy failed." | Out-Host 
			}
	Else {
		"File not found." | Out-Host 
		}
	}
}

# w32tm /query /status for local machine, PDC, and authenticating DC.
$OutputFile = $ComputerName + "_W32TM_Query_Status-output.TXT"	#_#

$Domain = [adsi]("LDAP://RootDSE")
$AUTHDC_DNSHOSTNAME = $Domain.dnshostname
$DomainDN = $Domain.defaultNamingContext
 
$PDC_NTDS_DN = ([adsi]("LDAP://"+ $DomainDN)).fsmoroleowner
$PDC_NTDS = [adsi]("LDAP://"+ $PDC_NTDS_DN)
$PDC = $PDC_NTDS.psbase.get_parent() -ErrorAction SilentlyContinue
if ($PDC -ne $null) { $PDC_DNSHOSTNAME = $PDC.dnshostname }

"This output is best viewed in the Support Diagnostic Console (SDC) or Internet Explorer. " | Out-File -FilePath $OutputFile -append
" " | Out-File -FilePath $OutputFile -append
"The following errors are expected to occur under the following conditions: " | Out-File -FilePath $OutputFile -append
"   -  'Access is Denied' is expected if MSDT was run with an account that does not have local administrative rights on the target machine. " | Out-File -FilePath $OutputFile -append
"   -  'The procedure is out of range' is expected if the target machine is not running Windows Server 2008 or later. " | Out-File -FilePath $OutputFile -append
"   -  'The RPC server is unavailable' is expected if Windows Firewall is enabled on the target machine, or the target machine is otherwise unreachable. " | Out-File -FilePath $OutputFile -append
" " | Out-File -FilePath $OutputFile -append
" " | Out-File -FilePath $OutputFile -append
"Output of 'w32tm /query /status /verbose' - " | Out-File -FilePath $OutputFile -append
" " | Out-File -FilePath $OutputFile -append
cmd /d /c w32tm /query /status /verbose | Out-File -FilePath $OutputFile -append
" " | Out-File -FilePath $OutputFile -append

if ($Global:skipHang -ne $true) {  #_#
	If ($PDC_DNSHOSTNAME -ne $null) {
		"The PDC Emulator for this computer's domain is $PDC_DNSHOSTNAME" | Out-File -FilePath $OutputFile -append
		" " | Out-File -FilePath $OutputFile -append
		"Output of 'w32tm /query /computer:$PDC_DNSHOSTNAME /status /verbose' - " | Out-File -FilePath $OutputFile -append
		" " | Out-File -FilePath $OutputFile -append
		cmd /d /c w32tm /query /computer:$PDC_DNSHOSTNAME /status /verbose | Out-File -FilePath $OutputFile -append
		" " | Out-File -FilePath $OutputFile -append
		}
	Else {
		"Unable to determine the PDC Emulator for the domain." | Out-File -FilePath $OutputFile -append
		}

	If ($AUTHDC_DNSHOSTNAME -ne $null) {
		" " | Out-File -FilePath $OutputFile -append
		"This computer's authenticating domain controller is $AUTHDC_DNSHOSTNAME" | Out-File -FilePath $OutputFile -append
		" " | Out-File -FilePath $OutputFile -append
		"Output of 'w32tm /query /computer:$AUTHDC_DNSHOSTNAME' /status /verbose" | Out-File -FilePath $OutputFile -append
		" " | Out-File -FilePath $OutputFile -append
		cmd /d /c w32tm /query /computer:$AUTHDC_DNSHOSTNAME /status /verbose | Out-File -FilePath $OutputFile -append
		" " | Out-File -FilePath $OutputFile -append
		}
	Else {
		"Unable to determine this computer's authenticating domain controller." | Out-File -FilePath $OutputFile -append
		}

	If ($PDC_DNSHOSTNAME -ne $null) {
		"The PDC Emulator for this computer's domain is $PDC_DNSHOSTNAME" | Out-File (".\" + $ComputerName + "_W32TM_Stripchart.txt") -append
		" " | Out-File (".\" + $ComputerName + "_W32TM_Stripchart.txt") -append
		"Output of 'w32tm /stripchart /computer:$PDC_DNSHOSTNAME /samples:5 /dataonly' - " | Out-File (".\" + $ComputerName + "_W32TM_Stripchart.txt") -append
		" " | Out-File (".\" + $ComputerName + "_W32TM_Stripchart.txt") -append
		cmd /d /c w32tm /stripchart /computer:$PDC_DNSHOSTNAME /samples:5 /dataonly | Out-File (".\" + $ComputerName + "_W32TM_Stripchart.txt") -append
		" " | Out-File (".\" + $ComputerName + "_W32TM_Stripchart.txt") -append
		}
	Else {
		"Unable to determine the PDC Emulator for the domain." | Out-File (".\" + $ComputerName + "_W32TM_Stripchart.txt") -append
		}

	If ($AUTHDC_DNSHOSTNAME -ne $null) {
		" " | Out-File (".\" + $ComputerName + "_W32TM_Stripchart.txt") -append
		"This computer's authenticating domain controller is $AUTHDC_DNSHOSTNAME" | Out-File (".\" + $ComputerName + "_W32TM_Stripchart.txt") -append
		" " | Out-File (".\" + $ComputerName + "_W32TM_Stripchart.txt") -append
		"Output of 'w32tm /stripchart /computer:$AUTHDC_DNSHOSTNAME /samples:5 /dataonly" | Out-File (".\" + $ComputerName + "_W32TM_Stripchart.txt") -append
		" " | Out-File (".\" + $ComputerName + "_W32TM_Stripchart.txt") -append
		cmd /d /c w32tm /stripchart /computer:$AUTHDC_DNSHOSTNAME /samples:5 /dataonly | Out-File (".\" + $ComputerName + "_W32TM_Stripchart.txt") -append
		" " | Out-File (".\" + $ComputerName + "_W32TM_Stripchart.txt") -append
		}
	Else {
		"Unable to determine this computer's authenticating domain controller." | Out-File (".\" + $ComputerName + "_W32TM_Stripchart.txt") -append
		}
} #_#
$OutputFile1 = join-path $pwd.path ($ComputerName + "_W32Time_Service_Status.txt")
#$command1 = "cmd.exe /d /c sc query w32time > " + $ComputerName + "_W32Time_Service_Status.txt"
$command1 = $Env:windir + "\system32\cmd.exe /d /c sc query w32time > `"$OutputFile1`""

$OutputFile2 = join-path $pwd.path ($ComputerName + "_W32Time_Service_Perms.txt")
#$command2 = "cmd.exe /d /c sc sdshow w32time > " + $ComputerName + "_W32Time_Service_Perms.txt"
$command2 = $Env:windir + "\system32\cmd.exe /d /c sc sdshow w32time > `"$OutputFile2`""

Write-DiagProgress -Activity $W32TimeStrings.ID_W32TimeOutput -Status "w32tm /monitor"
$OutputFile3 = join-path $pwd.path ($ComputerName + "_W32TM_Monitor.txt")
#$command3 = "cmd.exe /d /c w32tm /monitor > " + $ComputerName + "_W32TM_Monitor.txt"
$command3 = $Env:windir + "\system32\cmd.exe /d /c w32tm /monitor > `"$OutputFile3`""

Write-DiagProgress -Activity $W32TimeStrings.ID_W32TimeOutput -Status "w32tm /testif /qps"
$OutputFile4 = join-path $pwd.path ($ComputerName + "_W32TM_TestIf_QPS.txt")
#$command4 = "cmd.exe /d /c w32tm /testif /qps > " + $ComputerName + "_W32TM_TestIf_QPS.txt"
$command4 = $Env:windir + "\system32\cmd.exe /d /c w32tm /testif /qps > `"$OutputFile4`""

$OutputFile5 = join-path $pwd.path ($ComputerName + "_W32TM_TZ.txt")
#$command5 = "cmd.exe /d /c w32tm /tz > " + $ComputerName + "_W32TM_TZ.txt"
$command5 = $Env:windir + "\system32\cmd.exe /d /c w32tm /tz > `"$OutputFile5`""

CollectFiles -filesToCollect ($ComputerName + "_W32Time.log") -fileDescription "W32Time Debug Log" -sectionDescription "W32Time" -noFileExtensionsOnDescription
#RegQuery -RegistryKeys "HKLM\SYSTEM\CurrentControlSet\Services\W32Time" -OutputFile (".\" + $ComputerName + "_W32Time_Reg_Key.txt") -fileDescription "W32Time Reg Key" -sectionDescription "W32Time" -recursive $true
RegQuery -RegistryKeys "HKLM\SYSTEM\CurrentControlSet\Services\W32Time" -OutputFile ($ComputerName + "_W32Time_Reg_Key.txt") -fileDescription "W32Time Reg Key" -sectionDescription "W32Time" -recursive $true #_# removed .\ /WalterE

Get-Acl HKLM:\SYSTEM\CurrentControlSet\services\W32Time | Format-List | Out-File (".\" + $ComputerName + "_W32Time_Reg_Key_Perms.txt")
CollectFiles -filesToCollect ($ComputerName + "_W32Time_Reg_Key_Perms.txt") -fileDescription "W32Time Reg Key Perms" -sectionDescription "W32Time" -noFileExtensionsOnDescription
RunCmD -commandToRun $command1 -sectionDescription "W32Time" -filesToCollect $OutputFile1 -fileDescription "W32Time Service Status" -noFileExtensionsOnDescription
#RunCmD -commandToRun $command2 -sectionDescription "W32Time" -filesToCollect $OutputFile2 -fileDescription "W32Time Service Perms" -noFileExtensionsOnDescription
#RunCmD -commandToRun $command3 -sectionDescription "W32Time" -filesToCollect $OutputFile3 -fileDescription "W32TM /Monitor" -noFileExtensionsOnDescription
RunCmD -commandToRun $command4 -sectionDescription "W32Time" -filesToCollect $OutputFile4 -fileDescription "W32TM /TestIf /QPS" -noFileExtensionsOnDescription
### (Andret) Removed due http://bugcheck/Bugs/WindowsOSBugs/1879349 and http://bugcheck/bugs/Windows7/35226
### RunCmD -commandToRun $command5 -sectionDescription "W32Time" -filesToCollect $OutputFile5 -fileDescription "W32TM /TZ" -noFileExtensionsOnDescription

CollectFiles -filesToCollect ($ComputerName + "_W32TM_Query_Status.txt") -fileDescription "W32TM Query Status" -sectionDescription "W32Time" -noFileExtensionsOnDescription
CollectFiles -filesToCollect ($ComputerName + "_W32TM_Stripchart.txt") -fileDescription "W32TM Stripchart" -sectionDescription "W32Time" -noFileExtensionsOnDescription

Trap{WriteTo-StdOut "$($_.InvocationInfo.ScriptName)($($_.InvocationInfo.ScriptLineNumber)): $_" -shortformat;Continue}

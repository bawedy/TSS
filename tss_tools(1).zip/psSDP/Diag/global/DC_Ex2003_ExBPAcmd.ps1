﻿#************************************************
# DS_Ex2003_ExBPAcmd.ps1
# 2019-03-17 WalterE added Trap #_#

Trap [Exception]
	{
	 # Handle exception and throw it to the stdout log file. Then continue with function and script.
		 $Script:ExceptionMessage = $_
		 "[info]: Exception occurred."  | WriteTo-StdOut
		 "[info]: Exception.Message $ExceptionMessage."  | WriteTo-StdOut 
		 $Error.Clear()
		 continue
	}

if($debug -eq $true){[void]$shell.popup("Running DC_Ex2003_ExBPA.ps1")}

Import-LocalizedData -BindingVariable ExBPAStrings

Write-DiagProgress -Activity $ExBPAStrings.ID_Ex2003_ExBPAAct -Status $ExBPAStrings.ID_Ex2003_ExBPAStat

$OutputFile = join-path $pwd.path ("*_ExBPA.xml*")

$CommandLineToExpandExBPA = "expand.exe `"" + (Join-Path -Path $PWD.Path -ChildPath "ExBPAcmd2003.cab") + "`" -F:* `"" + $PWD.Path + "`""

RunCmd -commandToRun $CommandLineToExpandExBPA

$CommandLineToExecute = ($Env:windir + "\system32\cscript.exe ExBPAcmd2003.VBS")

if($debug -eq $true){[void]$shell.popup("Command line: $CommandLineToExecute")}

RunCmD -commandToRun $CommandLineToExecute -sectionDescription $ExBPAStrings.ID_Ex2003_ExBPAReportSection -filesToCollect $OutputFile -fileDescription $ExBPAStrings.ID_Ex2003_ExBPAFileDescription -BackgroundExecution -useSystemDiagnosticsObject

if($debug -eq $true){[void]$shell.popup("Ran DC_Ex2003_ExBPA.ps1")}

Trap{WriteTo-StdOut "$($_.InvocationInfo.ScriptName)($($_.InvocationInfo.ScriptLineNumber)): $_" -shortformat;Continue}
